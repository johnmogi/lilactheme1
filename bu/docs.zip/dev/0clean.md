C:\Users\anist\Desktop\CLIENTS\AVIV\LILAC\app\public\wp-content\themes\hello-theme-child-master\includes\integrations\class-ultimate-member-integration.php

C:\Users\anist\Desktop\CLIENTS\AVIV\LILAC\app\public\wp-content\themes\hello-theme-child-master\src\Login\PMProRoleSync.php

these 2 files are depraceted - clean remove