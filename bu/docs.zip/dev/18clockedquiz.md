allright we now want to add real theory tests just like in the old site


a clocked quiz is a quiz that has a time limit 
so we need to place the clock on the front in a big display for the user
