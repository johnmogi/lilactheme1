
C:\Users\anist\Desktop\CLIENTS\AVIV\LILAC\app\public

i want you to take a look at this wordpress instalation

this is more a woocomerce learndash enviroment
this is a LearnDash/WooCommerce integration with:

User registration flow using [code_registration] shortcode
Auto-enrollment into courses (course_id 898) and groups (group_id 1294)
Role assignment ("school_student")
Key observations:

The registration process is being logged but some entries show reg_code_exists as empty
The page template is simple but relies on the shortcode for functionality


we are going to build the screens one by one and take care of the flow, slowly
look here
C:\Users\anist\Desktop\CLIENTS\AVIV\LILAC\knowledgebase

currently i am looking for a folder based approch developiong the following feature onto the woocommerce products- the ability to "turn those on and off"
כל הקטגוריות והמוצרים אפשר להפעיל באתר ואפשר לכבות.  