<div class="elementor-element elementor-element-2a19fa2 elementor-widget elementor-widget-shortcode" data-id="2a19fa2" data-element_type="widget" data-widget_type="shortcode.default">
				<div class="elementor-widget-container">
							<div class="elementor-shortcode"><div class="learndash user_has_no_access" id="learndash_post_1367"><div class="learndash-wrapper">

<div class="ld-tabs ld-tab-count-1">
	
	<div class="ld-tabs-content">
		
			<div aria-labelledby="ld-content-tab-1219" class="ld-tab-content ld-visible" id="ld-tab-content-1219" role="tabpanel" tabindex="0">
											</div>

			
	</div> <!--/.ld-tabs-content-->

</div> <!--/.ld-tabs-->
		<div class="wpProQuiz_content" id="wpProQuiz_9" data-quiz-meta="{&quot;quiz_pro_id&quot;:9,&quot;quiz_post_id&quot;:1367}">
			<div class="wpProQuiz_spinner" style="display: none;">
				<div></div>
			</div>
			<div class="wpProQuiz_description"><p>לפניך שאלות לפי נושאי לימוד למבחן התיאוריה. תשובה שגויה מסומנת באדום.<br>
באתר ישנו מנגנון ייחודי של קבלת רמזים לכל שאלה. ללמידה נכונה העזרו במנגון הרמזים. לתיקון התשובה לחצו: קבל רמז!</p>
<p><img decoding="async" src="https://lilac.local/wp-content/uploads/2025/02/noPic.png" alt="" width="290" height="180"></p>
<p><a role="button"><br>
קח רמז<br>
</a></p>
</div><div style="display: none;" class="wpProQuiz_time_limit">
	<div class="time">
		זמן מוגבל: <span>0</span>	</div>
	<div class="wpProQuiz_progress"></div>
</div>
<div class="wpProQuiz_checkPage" style="display: none;">
	<h4 class="wpProQuiz_header">
	תקציר המבחן	</h4>
	<p><span>0</span> מתוך 8 שאלות הושלמו</p>	<p>שאלות:</p>
	<div class="wpProQuiz_reviewSummary"></div>

	
	<input type="button" name="endQuizSummary" value="סיים מבחן" class="wpProQuiz_button"> </div>
<div class="wpProQuiz_infopage" style="display: none;">
	<h4>מידע</h4>
		<input type="button" name="endInfopage" value="סיים מבחן" class="wpProQuiz_button"> </div>
<div class="wpProQuiz_text" style="display: none;">
		<div>
		<input class="wpProQuiz_button" type="button" value="התחל מבחן" name="startQuiz">	</div>
</div>
<div style="display: none;" class="wpProQuiz_lock">		
	<p>כבר השלמת את המבחן בעבר. לכן אינך יכול להתחיל אותו שוב.</p></div>
<div style="display: none;" class="wpProQuiz_loadQuiz">
	<p>
		המבחן נטען…	</p>
</div>
<div style="display: none;" class="wpProQuiz_startOnlyRegisteredUser">
	<p>עליך להתחבר או להירשם כדי להתחיל את המבחן.</p></div>
<div style="display: none;" class="wpProQuiz_prerequisite">
	<p>אתה חייב להשלים קודם את הבאים: <span></span></p></div>
<div style="display: none;" class="wpProQuiz_sending">
	<h4 class="wpProQuiz_header">תוצאות</h4>
	<p>
		</p><div>
		מבחןהושלם. התוצאות נרשמות.		</div>
		<div>
			<dd class="course_progress">
				<div class="course_progress_blue sending_progress_bar" style="width: 0%;">
				</div>
			</dd>
		</div>
	<p></p>
</div>

<div style="display: none;" class="wpProQuiz_results">
	<h4 class="wpProQuiz_header">תוצאות</h4>
	<p><span class="wpProQuiz_correct_answer">0</span> מתוך <span>8</span> שאלות נענו נכון</p>		<p class="wpProQuiz_quiz_time">
		הזמן שלך: <span></span>		</p>
			<p class="wpProQuiz_time_limit_expired" style="display: none;">
	זמן חלף	</p>

			<p class="wpProQuiz_points">
		השגת <span>0</span> מתוך <span>0</span> נקודה(ות), (<span>0</span>)		</p>
		<p class="wpProQuiz_graded_points" style="display: none;">
		נקודה(ות) שקיבלת: <span>0</span> מתוך <span>0</span>, (<span>0</span>)		<br>
		<span>0</span> שאלות פתוחות בהמתנה (נקודה(ות) אפשרית(יות): <span>0</span>)		<br>
		</p>
		
	<div class="wpProQuiz_catOverview" style="display:none;">
		<h4>
		קטגוריות		</h4>

		<div style="margin-top: 10px;">
			<ol>
							<li data-category_id="0">
					<span class="wpProQuiz_catName">כללי</span>
					<span class="wpProQuiz_catPercent">0%</span>
				</li>
							</ol>
		</div>
	</div>
	<div>
		<ul class="wpProQuiz_resultsList">
							<li style="display: none;">
					<div>
											</div>
				</li>
					</ul>
	</div>
		<div class="ld-quiz-actions" style="margin: 10px 0px;">
				<div class="quiz_continue_link
				">

		</div>
					<input class="wpProQuiz_button wpProQuiz_button_restartQuiz" type="button" name="restartQuiz" value="התחל מבחן מחדש">						<input class="wpProQuiz_button wpProQuiz_button_reShowQuestion" type="button" name="reShowQuestion" value="הצג שאלות">					</div>
</div>
<div class="wpProQuiz_reviewDiv" style="">
	<div class="wpProQuiz_reviewQuestion">
	<ol style="margin-top: 0px !important">
					<li class="wpProQuiz_reviewQuestionTarget wpProQuiz_reviewQuestionSolvedIncorrect">1</li>
					<li>2</li>
					<li>3</li>
					<li>4</li>
					<li>5</li>
					<li>6</li>
					<li>7</li>
					<li>8</li>
			</ol>
	<div style="display: none; top: 0px;"></div>
</div>
<div class="wpProQuiz_reviewLegend">
	<ol>
		<li class="learndash-quiz-review-legend-item-current">
			<span class="wpProQuiz_reviewColor wpProQuiz_reviewQuestion_Target"></span>
			<span class="wpProQuiz_reviewText">הנוכחי</span>
		</li>
		<li class="learndash-quiz-review-legend-item-review">
			<span class="wpProQuiz_reviewColor wpProQuiz_reviewColor_Review"></span>
			<span class="wpProQuiz_reviewText">ביקורת</span>
		</li>
		<li class="learndash-quiz-review-legend-item-answered">
			<span class="wpProQuiz_reviewColor wpProQuiz_reviewColor_Answer"></span>
			<span class="wpProQuiz_reviewText">נענו</span>
		</li>
		<li class="learndash-quiz-review-legend-item-correct">
			<span class="wpProQuiz_reviewColor wpProQuiz_reviewColor_AnswerCorrect"></span>
			<span class="wpProQuiz_reviewText">נכון</span>
		</li>
		<li class="learndash-quiz-review-legend-item-incorrect">
			<span class="wpProQuiz_reviewColor wpProQuiz_reviewColor_AnswerIncorrect"></span>
			<span class="wpProQuiz_reviewText">לא נכון</span>
		</li>
	</ol>
	<div style="clear: both;"></div>
</div>
<div class="wpProQuiz_reviewButtons">
			<input type="button" name="review" value="סקור שאלה" class="wpProQuiz_button2" style="float: left; display: block;"> 				<div style="clear: both;"></div>
	</div>
</div>
<div class="wpProQuiz_quizAnker" style="display: none;"></div>
<div style="" class="wpProQuiz_quiz">
	<ol class="wpProQuiz_list">
					<li class="wpProQuiz_listItem" style="" data-type="single" data-question-meta="{&quot;type&quot;:&quot;single&quot;,&quot;question_pro_id&quot;:41,&quot;question_post_id&quot;:1369}">
				<div class="wpProQuiz_question_page" style="display:none;">
				שאלה <span>1</span> מתוך <span>8</span>				</div>
				<h5 style="display: none;" class="wpProQuiz_header">
					<span>1</span>. שאלה
				</h5>

				
								<div class="wpProQuiz_question" style="margin: 10px 0px 0px 0px;">
					<div class="wpProQuiz_question_text">
						<p>מהם מרכיבי ה"מרחב התעבורתי"?</p>
					</div>
					<p class="wpProQuiz_clear" style="clear:both;"></p>

										
										<ul class="wpProQuiz_questionList" data-question_id="41" data-type="single">
						
								<li class="wpProQuiz_questionListItem wpProQuiz_answerIncorrect" data-pos="0">
																			<span style="display:none;">1. </span>
										<label class="is-selected">
											<input class="wpProQuiz_questionInput" autocomplete="off" type="radio" name="question_9_41" value="1" disabled="disabled"> כל מה שנמצא בעולם, כולל הרכוש ומזג האוויר שבתוך הבתים.										</label>

																		</li>
								
								<li class="wpProQuiz_questionListItem wpProQuiz_answerCorrectIncomplete" data-pos="1">
																			<span style="display:none;">2. </span>
										<label>
											<input class="wpProQuiz_questionInput" autocomplete="off" type="radio" name="question_9_41" value="2" disabled="disabled"> כל מה שנמצא בדרך וכל מי שמשתמש בדרך: פני הדרך, עוברי דרך, כלי הרכב ותנאי הסביבה.										</label>

																		</li>
								
								<li class="wpProQuiz_questionListItem" data-pos="2">
																			<span style="display:none;">3. </span>
										<label>
											<input class="wpProQuiz_questionInput" autocomplete="off" type="radio" name="question_9_41" value="3" disabled="disabled"> מרכיבים ששייכים לעולם התעבורה בלבד: עוברי דרך וכלי רכב.										</label>

																		</li>
								
								<li class="wpProQuiz_questionListItem" data-pos="3">
																			<span style="display:none;">4. </span>
										<label>
											<input class="wpProQuiz_questionInput" autocomplete="off" type="radio" name="question_9_41" value="4" disabled="disabled"> מרכיבים ששייכים למרחב בלבד: פני הדרך ותנאי הסביבה.										</label>

																		</li>
													</ul>
									</div>
									<div class="wpProQuiz_response" style="">
						<div style="display: none;" class="wpProQuiz_correct">
															<span>
								נכון								</span>
														<div class="wpProQuiz_AnswerMessage"></div>
						</div>
						<div style="" class="wpProQuiz_incorrect">
															<span>
								לא נכון							</span>
														<div class="wpProQuiz_AnswerMessage"></div>
						</div>
					</div>
				
									<div class="wpProQuiz_tipp" style="position: relative; display: none;">
						<div>
							<h5 style="margin: 0px 0px 10px;" class="wpProQuiz_header">
							רמז							</h5>
							<p>המרחב התעבורתי הוא מושג רחב הכולל בתוכו את כל מה שנמצא בדרך, את כל מי שמשתמש בדרך ואת כל מה שיש לו השפעה על הנסיעה בדרך.<br>
למרחב התעבורתי חברו ארבעה שותפים מרכזיים:</p>
<p><span class="highlight-hint">א. פני הדרך – כל מה שישנו בדרך ובסביבתה: מרחבים פתוחים, מרחבים בנויים, כבישים, מדרכות, תמרורים ורמזורים, ועוד. ב. עוברי הדרך – כל משתמשי הדרך הנמצאים בה לכל מטרה: להליכה, לרכיבה, לנסיעה ועוד. ג. כלי רכב – כל כלי הרכב הנעים בדרך על מאפייניהם וסוגיהם השונים. ד. הסביבה – כל תנאי שמשפיע על הנסיעה כגון: תנאי הנראות, שעות היום או הלילה או כמות הנוסעים בכביש.</span></p>
<p>כפי שתראו בתמונה, להקות בעלי חיים יכולות לנוע בצפיפות כגוף אחד מבלי להתנגש אחד בשני ובלי נפגעים.</p>
<p>שלושה מאפיינים עיקריים למרחב התעבורתי:</p>
<p>א. תנועה רבה ומהירה</p>
<p>ב. שונות ורבגוניות של משתמשי הדרך או של הרכבים הנעים בדרך, כגון השוני העצום שקיים בין רכב לבין אופנוע, או בין נהג ותיק ובעל ניסיון לנהג צעיר חדש חסר ניסיון.</p>
<p>ג. ריבוי מפגשים בין משתמשי הדרך – כל גורם הנע במרחב התעבורתי נתקל בדרכו במשתמשי דרך אחרים הנעים לצידו ומה שיקרה במפגש ביניהם תלוי באמצעי הזהירות שנקטו בהם.</p>
<p>נסכם ונאמר כי סכנות ואי וודאות רבה מאפיינות את המרחב התעבורתי בשל מאפייניו</p>
<p>מורכבותה של מטלת הנהיגה</p>
<p>הנהיגה היא מטלה מורכבת ומסובכת. תראו כמה פעולות על הנהג לבצע בזמן קצר: עליו לאסוף מידע על הסביבה. היות והדרך מתאפיינת בתנועה רבה ומהירה, בשונות גדולה בין משתתפי הדרך ובריבוי מפגשים ביניהם – פעולת איסוף המידע קשה במיוחד שהרי הסביבה משתנה או יכולה להשתנות בכל רגע.</p>
<p>משימה:</p>
<p>לפניכם סרטון הממחיש ומדגים את מורכבות מטלת הנהיגה ביום רגיל במנהטן. בתמונות דומות תתקלו גם בארצנו בערים הגדולות.</p>
<p>התוכלו להצביע על הרגעים בסרטון בהם הנהיגה מורכבת ומחייבת זהירות ועירנות רבה מצד הנהג? רשמו במהלך הצפייה לפחות 5 מצבים שדרשו מהנהג היערכות מיוחדת ותשומת לב מירבית.</p>
<p>הפנייה לסרטון מתוך “תורת החינוך התעבורתי” פרק 1 עמ` 11-12.</p>
<p>למורה: מומלץ מומלץ לעצור את הסרטון מפעם לפעם, לשתף את התלמידים ולהדגיש בפניהם את המורכבות של מצבי הנהיגה שראו בסרטון זה עתה.</p>
<p>מהירות התנועה היא נתון משפיע ביותר. פעמים רבות אירועים מתרחשים בקצב מהיר הרבה יותר ממה שנדרש לאדם באופן טבעי כדי להגיב להם. בנוסף, לכל נהג רצון משלו שמנוגד לעיתים לרצון חברו ופעמים רבות לנהגים אין רגישות מספקת לזולת ונהג צריך לקחת זאת בחשבון.</p>
<p>לכן נכון יהיה לחזור ולהזכיר שהמרחב התעבורתי מתאפיין באי ודאות ובסכנות רבות.</p>
<div class="btn-wrapper"><button id="mark-hint" type="button">סמן רמז</button><br>
<button id="close-hint" type="button">סגור רמז</button></div>
						</div>
					</div>
				
													<input type="button" name="next" value="הבא" class="wpProQuiz_button wpProQuiz_QuestionButton" style="float: left; margin-right: 10px;" data-question-lock="true"> 													<input type="button" name="tip" value="רמז" class="wpProQuiz_button wpProQuiz_QuestionButton wpProQuiz_TipButton" style="float: left ; display: inline-block; margin-right: 10px ;"> 								<input type="button" name="check" value="סמן" class="wpProQuiz_button wpProQuiz_QuestionButton" style="float: right; margin-right: 10px; display: none;"> 								<input type="button" name="back" value="חזרה" class="wpProQuiz_button wpProQuiz_QuestionButton" style="float: right; display: none;"> 								<div style="clear: both;"></div>

							</li>

					<li class="wpProQuiz_listItem" style="display: none;" data-type="single" data-question-meta="{&quot;type&quot;:&quot;single&quot;,&quot;question_pro_id&quot;:42,&quot;question_post_id&quot;:1370}">
				<div class="wpProQuiz_question_page" style="display:none;">
				שאלה <span>2</span> מתוך <span>8</span>				</div>
				<h5 style="display: none;" class="wpProQuiz_header">
					<span>2</span>. שאלה
				</h5>

				
								<div class="wpProQuiz_question" style="margin: 10px 0px 0px 0px;">
					<div class="wpProQuiz_question_text">
						<p>במרחב התעבורתי מתקיימים מפגשים רבים בין עוברי דרך בהם עליהם להתחשב אחד בשני. נכון או לא נכון?</p>
					</div>
					<p class="wpProQuiz_clear" style="clear:both;"></p>

										
										<ul class="wpProQuiz_questionList" data-question_id="42" data-type="single">
						
								<li class="wpProQuiz_questionListItem" data-pos="0">
																			<span style="display:none;">1. </span>
										<label>
											<input class="wpProQuiz_questionInput" autocomplete="off" type="radio" name="question_9_42" value="1"> לא נכון. אם עוברי הדרך ינהגו לפי הוראות החוק לא יתקיימו נקודות מגע ביניהם.										</label>

																		</li>
								
								<li class="wpProQuiz_questionListItem" data-pos="1">
																			<span style="display:none;">2. </span>
										<label>
											<input class="wpProQuiz_questionInput" autocomplete="off" type="radio" name="question_9_42" value="2"> לא נכון, בכל מקרה במרחב התעבורתי אין מפגשים בין עוברי דרך.										</label>

																		</li>
								
								<li class="wpProQuiz_questionListItem" data-pos="2">
																			<span style="display:none;">3. </span>
										<label>
											<input class="wpProQuiz_questionInput" autocomplete="off" type="radio" name="question_9_42" value="3"> לא נכון, כל אחד ממשתמשי הדרך נע בנתיב שלו ולא נפגש עם אחרים.										</label>

																		</li>
								
								<li class="wpProQuiz_questionListItem" data-pos="3">
																			<span style="display:none;">4. </span>
										<label>
											<input class="wpProQuiz_questionInput" autocomplete="off" type="radio" name="question_9_42" value="4"> נכון, מפגשים מתקיימים במרחב התעבורתי בכל שעות היום ובכל מקום בדרך.										</label>

																		</li>
													</ul>
									</div>
									<div class="wpProQuiz_response" style="display: none;">
						<div style="display: none;" class="wpProQuiz_correct">
															<span>
								נכון								</span>
														<div class="wpProQuiz_AnswerMessage"></div>
						</div>
						<div style="display: none;" class="wpProQuiz_incorrect">
															<span>
								לא נכון							</span>
														<div class="wpProQuiz_AnswerMessage"></div>
						</div>
					</div>
				
									<div class="wpProQuiz_tipp" style="display: none; position: relative;">
						<div>
							<h5 style="margin: 0px 0px 10px;" class="wpProQuiz_header">
							רמז							</h5>
							<p>המרחב התעבורתי הוא מושג רחב הכולל בתוכו את כל מה שנמצא בדרך, את כל מי שמשתמש בדרך ואת כל מה שיש לו השפעה על הנסיעה בדרך.<br>
למרחב התעבורתי חברו ארבעה שותפים מרכזיים:</p>
<p>א. פני הדרך – כל מה שישנו בדרך ובסביבתה: מרחבים פתוחים, מרחבים בנויים, כבישים, מדרכות, תמרורים ורמזורים, ועוד. ב.עוברי הדרך – כל משתמשי הדרך הנמצאים בה לכל מטרה: להליכה, לרכיבה, לנסיעה ועוד. ג. כלי רכב – כל כלי הרכב הנעים בדרך על מאפייניהם וסוגיהם השונים. ד. הסביבה – כל תנאי שמשפיע על הנסיעה כגון: תנאי הנראות, שעות היום או הלילה או כמות הנוסעים בכביש.</p>
<p>כפי שתראו בתמונה, להקות בעלי חיים יכולות לנוע בצפיפות כגוף אחד מבלי להתנגש אחד בשני ובלי נפגעים.</p>
<p>שלושה מאפיינים עיקריים למרחב התעבורתי:</p>
<p>א. תנועה רבה ומהירה</p>
<p>ב. שונות ורבגוניות של משתמשי הדרך או של הרכבים הנעים בדרך, כגון השוני העצום שקיים בין רכב לבין אופנוע, או בין נהג ותיק ובעל ניסיון לנהג צעיר חדש חסר ניסיון.</p>
<p>ג. <span class="highlight-hint">ריבוי מפגשים בין משתמשי הדרך – כל גורם הנע במרחב התעבורתי נתקל בדרכו במשתמשי דרך אחרים הנעים לצידו ומה שיקרה במפגש ביניהם תלוי באמצעי הזהירות שנקטו בהם.</span></p>
<p>נסכם ונאמר כי סכנות ואי וודאות רבה מאפיינות את המרחב התעבורתי בשל מאפייניו</p>
<p>מורכבותה של מטלת הנהיגה</p>
<p>הנהיגה היא מטלה מורכבת ומסובכת. תראו כמה פעולות על הנהג לבצע בזמן קצר: עליו לאסוף מידע על הסביבה. היות והדרך מתאפיינת בתנועה רבה ומהירה, בשונות גדולה בין משתתפי הדרך ובריבוי מפגשים ביניהם – פעולת איסוף המידע קשה במיוחד שהרי הסביבה משתנה או יכולה להשתנות בכל רגע.</p>
<p>משימה:</p>
<p>לפניכם סרטון הממחיש ומדגים את מורכבות מטלת הנהיגה ביום רגיל במנהטן. בתמונות דומות תתקלו גם בארצנו בערים הגדולות.</p>
<p>התוכלו להצביע על הרגעים בסרטון בהם הנהיגה מורכבת ומחייבת זהירות ועירנות רבה מצד הנהג? רשמו במהלך הצפייה לפחות 5 מצבים שדרשו מהנהג היערכות מיוחדת ותשומת לב מירבית.</p>
<p>הפנייה לסרטון מתוך “תורת החינוך התעבורתי” פרק 1 עמ` 11-12.</p>
<p>למורה: מומלץ מומלץ לעצור את הסרטון מפעם לפעם, לשתף את התלמידים ולהדגיש בפניהם את המורכבות של מצבי הנהיגה שראו בסרטון זה עתה.</p>
<p>מהירות התנועה היא נתון משפיע ביותר. פעמים רבות אירועים מתרחשים בקצב מהיר הרבה יותר ממה שנדרש לאדם באופן טבעי כדי להגיב להם. בנוסף, לכל נהג רצון משלו שמנוגד לעיתים לרצון חברו ופעמים רבות לנהגים אין רגישות מספקת לזולת ונהג צריך לקחת זאת בחשבון.</p>
<p>לכן נכון יהיה לחזור ולהזכיר שהמרחב התעבורתי מתאפיין באי ודאות ובסכנות רבות.</p>
<div class="btn-wrapper"><button id="mark-hint" type="button">סמן רמז</button><br>
<button id="close-hint" type="button">סגור רמז</button></div>
						</div>
					</div>
				
													<input type="button" name="next" value="הבא" class="wpProQuiz_button wpProQuiz_QuestionButton" style="float: left ; margin-right: 10px ; display: none;"> 													<input type="button" name="tip" value="רמז" class="wpProQuiz_button wpProQuiz_QuestionButton wpProQuiz_TipButton" style="float: left ; display: inline-block; margin-right: 10px ;"> 								<input type="button" name="check" value="סמן" class="wpProQuiz_button wpProQuiz_QuestionButton" style="float: right; margin-right: 10px;"> 								<input type="button" name="back" value="חזרה" class="wpProQuiz_button wpProQuiz_QuestionButton" style="float: right; display: none;"> 								<div style="clear: both;"></div>

							</li>

					<li class="wpProQuiz_listItem" style="display: none;" data-type="single" data-question-meta="{&quot;type&quot;:&quot;single&quot;,&quot;question_pro_id&quot;:43,&quot;question_post_id&quot;:1371}">
				<div class="wpProQuiz_question_page" style="display:none;">
				שאלה <span>3</span> מתוך <span>8</span>				</div>
				<h5 style="display: none;" class="wpProQuiz_header">
					<span>3</span>. שאלה
				</h5>

				
								<div class="wpProQuiz_question" style="margin: 10px 0px 0px 0px;">
					<div class="wpProQuiz_question_text">
						<p>הנהיגה היא משימה מורכבת. נכון או לא נכון?</p>
					</div>
					<p class="wpProQuiz_clear" style="clear:both;"></p>

										
										<ul class="wpProQuiz_questionList" data-question_id="43" data-type="single">
						
								<li class="wpProQuiz_questionListItem" data-pos="0">
																			<span style="display:none;">1. </span>
										<label>
											<input class="wpProQuiz_questionInput" autocomplete="off" type="radio" name="question_9_43" value="1"> לא נכון. רק כשיש עומס בדרכים לפעמים קשה לנהוג.										</label>

																		</li>
								
								<li class="wpProQuiz_questionListItem" data-pos="1">
																			<span style="display:none;">2. </span>
										<label>
											<input class="wpProQuiz_questionInput" autocomplete="off" type="radio" name="question_9_43" value="2"> לא נכון. רק נהגי משאיות כבדות מתעייפים בנהיגה בגלל משאם הכבד.										</label>

																		</li>
								
								<li class="wpProQuiz_questionListItem" data-pos="2">
																			<span style="display:none;">3. </span>
										<label>
											<input class="wpProQuiz_questionInput" autocomplete="off" type="radio" name="question_9_43" value="3"> נכון. מטלת הנהיגה דורשת ביצוע מספר מטלות במקביל ובזמן קצר וזה מורכב.										</label>

																		</li>
								
								<li class="wpProQuiz_questionListItem" data-pos="3">
																			<span style="display:none;">4. </span>
										<label>
											<input class="wpProQuiz_questionInput" autocomplete="off" type="radio" name="question_9_43" value="4"> נכון. אבל רק בגלל שלנהגים אין סבלנות והם לא מעניקים זכות קדימה כנדרש בחוק.										</label>

																		</li>
													</ul>
									</div>
									<div class="wpProQuiz_response" style="display: none;">
						<div style="display: none;" class="wpProQuiz_correct">
															<span>
								נכון								</span>
														<div class="wpProQuiz_AnswerMessage"></div>
						</div>
						<div style="display: none;" class="wpProQuiz_incorrect">
															<span>
								לא נכון							</span>
														<div class="wpProQuiz_AnswerMessage"></div>
						</div>
					</div>
				
									<div class="wpProQuiz_tipp" style="display: none; position: relative;">
						<div>
							<h5 style="margin: 0px 0px 10px;" class="wpProQuiz_header">
							רמז							</h5>
							<p>המרחב התעבורתי הוא מושג רחב הכולל בתוכו את כל מה שנמצא בדרך, את כל מי שמשתמש בדרך ואת כל מה שיש לו השפעה על הנסיעה בדרך.<br>
למרחב התעבורתי חברו ארבעה שותפים מרכזיים:</p>
<p>א. פני הדרך – כל מה שישנו בדרך ובסביבתה: מרחבים פתוחים, מרחבים בנויים, כבישים, מדרכות, תמרורים ורמזורים, ועוד. ב. עוברי הדרך – כל משתמשי הדרך הנמצאים בה לכל מטרה: להליכה, לרכיבה, לנסיעה ועוד. ג. כלי רכב – כל כלי הרכב הנעים בדרך על מאפייניהם וסוגיהם השונים. ד. הסביבה – כל תנאי שמשפיע על הנסיעה כגון: תנאי הנראות, שעות היום או הלילה או כמות הנוסעים בכביש</p>
<p>כפי שתראו בתמונה, להקות בעלי חיים יכולות לנוע בצפיפות כגוף אחד מבלי להתנגש אחד בשני ובלי נפגעים.</p>
<p>שלושה מאפיינים עיקריים למרחב התעבורתי:</p>
<p>א. תנועה רבה ומהירה</p>
<p>ב. שונות ורבגוניות של משתמשי הדרך או של הרכבים הנעים בדרך, כגון השוני העצום שקיים בין רכב לבין אופנוע, או בין נהג ותיק ובעל ניסיון לנהג צעיר חדש חסר ניסיון.</p>
<p>ג. ריבוי מפגשים בין משתמשי הדרך – כל גורם הנע במרחב התעבורתי נתקל בדרכו במשתמשי דרך אחרים הנעים לצידו ומה שיקרה במפגש ביניהם תלוי באמצעי הזהירות שנקטו בהם.</p>
<p>נסכם ונאמר כי סכנות ואי וודאות רבה מאפיינות את המרחב התעבורתי בשל מאפייניו</p>
<p>מורכבותה של מטלת הנהיגה</p>
<p><span class="highlight-hint">הנהיגה היא מטלה מורכבת ומסובכת. תראו כמה פעולות על הנהג לבצע בזמן קצר: עליו לאסוף מידע על הסביבה. היות והדרך מתאפיינת בתנועה רבה ומהירה, בשונות גדולה בין משתתפי הדרך ובריבוי מפגשים ביניהם – פעולת איסוף המידע קשה במיוחד שהרי הסביבה משתנה או יכולה להשתנות בכל רגע.</span></p>
<p>משימה:</p>
<p>לפניכם סרטון הממחיש ומדגים את מורכבות מטלת הנהיגה ביום רגיל במנהטן. בתמונות דומות תתקלו גם בארצנו בערים הגדולות.</p>
<p>התוכלו להצביע על הרגעים בסרטון בהם הנהיגה מורכבת ומחייבת זהירות ועירנות רבה מצד הנהג? רשמו במהלך הצפייה לפחות 5 מצבים שדרשו מהנהג היערכות מיוחדת ותשומת לב מירבית.</p>
<p>הפנייה לסרטון מתוך “תורת החינוך התעבורתי” פרק 1 עמ` 11-12.</p>
<p>למורה: מומלץ מומלץ לעצור את הסרטון מפעם לפעם, לשתף את התלמידים ולהדגיש בפניהם את המורכבות של מצבי הנהיגה שראו בסרטון זה עתה.</p>
<p>מהירות התנועה היא נתון משפיע ביותר. פעמים רבות אירועים מתרחשים בקצב מהיר הרבה יותר ממה שנדרש לאדם באופן טבעי כדי להגיב להם. בנוסף, לכל נהג רצון משלו שמנוגד לעיתים לרצון חברו ופעמים רבות לנהגים אין רגישות מספקת לזולת ונהג צריך לקחת זאת בחשבון.</p>
<p>לכן נכון יהיה לחזור ולהזכיר שהמרחב התעבורתי מתאפיין באי ודאות ובסכנות רבות.</p>
<div class="btn-wrapper"><button id="mark-hint" type="button">סמן רמז</button><br>
<button id="close-hint" type="button">סגור רמז</button></div>
						</div>
					</div>
				
													<input type="button" name="next" value="הבא" class="wpProQuiz_button wpProQuiz_QuestionButton" style="float: left ; margin-right: 10px ; display: none;"> 													<input type="button" name="tip" value="רמז" class="wpProQuiz_button wpProQuiz_QuestionButton wpProQuiz_TipButton" style="float: left ; display: inline-block; margin-right: 10px ;"> 								<input type="button" name="check" value="סמן" class="wpProQuiz_button wpProQuiz_QuestionButton" style="float: right; margin-right: 10px;"> 								<input type="button" name="back" value="חזרה" class="wpProQuiz_button wpProQuiz_QuestionButton" style="float: right; display: none;"> 								<div style="clear: both;"></div>

							</li>

					<li class="wpProQuiz_listItem" style="display: none;" data-type="single" data-question-meta="{&quot;type&quot;:&quot;single&quot;,&quot;question_pro_id&quot;:44,&quot;question_post_id&quot;:1372}">
				<div class="wpProQuiz_question_page" style="display:none;">
				שאלה <span>4</span> מתוך <span>8</span>				</div>
				<h5 style="display: none;" class="wpProQuiz_header">
					<span>4</span>. שאלה
				</h5>

				
								<div class="wpProQuiz_question" style="margin: 10px 0px 0px 0px;">
					<div class="wpProQuiz_question_text">
						<p>האם תלמיד נהיגה הוא חלק מהמרחב התעבורתי?</p>
					</div>
					<p class="wpProQuiz_clear" style="clear:both;"></p>

										
										<ul class="wpProQuiz_questionList" data-question_id="44" data-type="single">
						
								<li class="wpProQuiz_questionListItem" data-pos="0">
																			<span style="display:none;">1. </span>
										<label>
											<input class="wpProQuiz_questionInput" autocomplete="off" type="radio" name="question_9_44" value="1"> לא. רק אחרי שיקבל רישיון נהיגה יהפוך תלמיד נהיגה לחלק מהמרחב התעבורתי.										</label>

																		</li>
								
								<li class="wpProQuiz_questionListItem" data-pos="1">
																			<span style="display:none;">2. </span>
										<label>
											<input class="wpProQuiz_questionInput" autocomplete="off" type="radio" name="question_9_44" value="2"> לא. המרחב התעבורתי לא כולל תלמידי נהיגה הנוהגים ברכב ללימוד נהיגה.										</label>

																		</li>
								
								<li class="wpProQuiz_questionListItem" data-pos="2">
																			<span style="display:none;">3. </span>
										<label>
											<input class="wpProQuiz_questionInput" autocomplete="off" type="radio" name="question_9_44" value="3"> כן, אבל רק אם הוא נוהג בדרך בינעירונית.										</label>

																		</li>
								
								<li class="wpProQuiz_questionListItem" data-pos="3">
																			<span style="display:none;">4. </span>
										<label>
											<input class="wpProQuiz_questionInput" autocomplete="off" type="radio" name="question_9_44" value="4"> כן, כל מי שנמצא בדרך ומשתמש בה הוא חלק מהמרחב התעבורתי.										</label>

																		</li>
													</ul>
									</div>
									<div class="wpProQuiz_response" style="display: none;">
						<div style="display: none;" class="wpProQuiz_correct">
															<span>
								נכון								</span>
														<div class="wpProQuiz_AnswerMessage"></div>
						</div>
						<div style="display: none;" class="wpProQuiz_incorrect">
															<span>
								לא נכון							</span>
														<div class="wpProQuiz_AnswerMessage"></div>
						</div>
					</div>
				
									<div class="wpProQuiz_tipp" style="display: none; position: relative;">
						<div>
							<h5 style="margin: 0px 0px 10px;" class="wpProQuiz_header">
							רמז							</h5>
							<p><span class="highlight-hint">המרחב התעבורתי הוא מושג רחב הכולל בתוכו את כל מה שנמצא בדרך, את כל מי שמשתמש בדרך ואת כל מה שיש לו השפעה על הנסיעה בדרך.</span><br>
למרחב התעבורתי חברו ארבעה שותפים מרכזיים:</p>
<p>א. פני הדרך – כל מה שישנו בדרך ובסביבתה: מרחבים פתוחים, מרחבים בנויים, כבישים, מדרכות, תמרורים ורמזורים, ועוד. ב.עוברי הדרך – כל משתמשי הדרך הנמצאים בה לכל מטרה: להליכה, לרכיבה, לנסיעה ועוד. ג. כלי רכב – כל כלי הרכב הנעים בדרך על מאפייניהם וסוגיהם השונים. ד. הסביבה – כל תנאי שמשפיע על הנסיעה כגון: תנאי הנראות, שעות היום או הלילה או כמות הנוסעים בכביש.</p>
<p>כפי שתראו בתמונה, להקות בעלי חיים יכולות לנוע בצפיפות כגוף אחד מבלי להתנגש אחד בשני ובלי נפגעים.</p>
<p>שלושה מאפיינים עיקריים למרחב התעבורתי:</p>
<p>א. תנועה רבה ומהירה</p>
<p>ב. שונות ורבגוניות של משתמשי הדרך או של הרכבים הנעים בדרך, כגון השוני העצום שקיים בין רכב לבין אופנוע, או בין נהג ותיק ובעל ניסיון לנהג צעיר חדש חסר ניסיון.</p>
<p>ג. ריבוי מפגשים בין משתמשי הדרך – כל גורם הנע במרחב התעבורתי נתקל בדרכו במשתמשי דרך אחרים הנעים לצידו ומה שיקרה במפגש ביניהם תלוי באמצעי הזהירות שנקטו בהם.</p>
<p>נסכם ונאמר כי סכנות ואי וודאות רבה מאפיינות את המרחב התעבורתי בשל מאפייניו</p>
<p>מורכבותה של מטלת הנהיגה</p>
<p>הנהיגה היא מטלה מורכבת ומסובכת. תראו כמה פעולות על הנהג לבצע בזמן קצר: עליו לאסוף מידע על הסביבה. היות והדרך מתאפיינת בתנועה רבה ומהירה, בשונות גדולה בין משתתפי הדרך ובריבוי מפגשים ביניהם – פעולת איסוף המידע קשה במיוחד שהרי הסביבה משתנה או יכולה להשתנות בכל רגע.</p>
<p>משימה:</p>
<p>לפניכם סרטון הממחיש ומדגים את מורכבות מטלת הנהיגה ביום רגיל במנהטן. בתמונות דומות תתקלו גם בארצנו בערים הגדולות.</p>
<p>התוכלו להצביע על הרגעים בסרטון בהם הנהיגה מורכבת ומחייבת זהירות ועירנות רבה מצד הנהג? רשמו במהלך הצפייה לפחות 5 מצבים שדרשו מהנהג היערכות מיוחדת ותשומת לב מירבית.</p>
<p>הפנייה לסרטון מתוך “תורת החינוך התעבורתי” פרק 1 עמ` 11-12.</p>
<p>למורה: מומלץ מומלץ לעצור את הסרטון מפעם לפעם, לשתף את התלמידים ולהדגיש בפניהם את המורכבות של מצבי הנהיגה שראו בסרטון זה עתה.</p>
<p>מהירות התנועה היא נתון משפיע ביותר. פעמים רבות אירועים מתרחשים בקצב מהיר הרבה יותר ממה שנדרש לאדם באופן טבעי כדי להגיב להם. בנוסף, לכל נהג רצון משלו שמנוגד לעיתים לרצון חברו ופעמים רבות לנהגים אין רגישות מספקת לזולת ונהג צריך לקחת זאת בחשבון.</p>
<p>לכן נכון יהיה לחזור ולהזכיר שהמרחב התעבורתי מתאפיין באי ודאות ובסכנות רבות.</p>
<div class="btn-wrapper"><button id="mark-hint" type="button">סמן רמז</button><br>
<button id="close-hint" type="button">סגור רמז</button></div>
						</div>
					</div>
				
													<input type="button" name="next" value="הבא" class="wpProQuiz_button wpProQuiz_QuestionButton" style="float: left ; margin-right: 10px ; display: none;"> 													<input type="button" name="tip" value="רמז" class="wpProQuiz_button wpProQuiz_QuestionButton wpProQuiz_TipButton" style="float: left ; display: inline-block; margin-right: 10px ;"> 								<input type="button" name="check" value="סמן" class="wpProQuiz_button wpProQuiz_QuestionButton" style="float: right; margin-right: 10px;"> 								<input type="button" name="back" value="חזרה" class="wpProQuiz_button wpProQuiz_QuestionButton" style="float: right; display: none;"> 								<div style="clear: both;"></div>

							</li>

					<li class="wpProQuiz_listItem" style="display: none;" data-type="single" data-question-meta="{&quot;type&quot;:&quot;single&quot;,&quot;question_pro_id&quot;:45,&quot;question_post_id&quot;:1373}">
				<div class="wpProQuiz_question_page" style="display:none;">
				שאלה <span>5</span> מתוך <span>8</span>				</div>
				<h5 style="display: none;" class="wpProQuiz_header">
					<span>5</span>. שאלה
				</h5>

				
								<div class="wpProQuiz_question" style="margin: 10px 0px 0px 0px;">
					<div class="wpProQuiz_question_text">
						<p>האם יש סיכונים במרחב התעבורתי?</p>
					</div>
					<p class="wpProQuiz_clear" style="clear:both;"></p>

										
										<ul class="wpProQuiz_questionList" data-question_id="45" data-type="single">
						
								<li class="wpProQuiz_questionListItem" data-pos="0">
																			<span style="display:none;">1. </span>
										<label>
											<input class="wpProQuiz_questionInput" autocomplete="off" type="radio" name="question_9_45" value="1"> ממש לא.										</label>

																		</li>
								
								<li class="wpProQuiz_questionListItem" data-pos="1">
																			<span style="display:none;">2. </span>
										<label>
											<input class="wpProQuiz_questionInput" autocomplete="off" type="radio" name="question_9_45" value="2"> כן, רק בדרכים בינעירוניות.										</label>

																		</li>
								
								<li class="wpProQuiz_questionListItem" data-pos="2">
																			<span style="display:none;">3. </span>
										<label>
											<input class="wpProQuiz_questionInput" autocomplete="off" type="radio" name="question_9_45" value="3"> כן, המרחב התעבורתי מאופיין באי ודאות ובסכנות רבות.										</label>

																		</li>
								
								<li class="wpProQuiz_questionListItem" data-pos="3">
																			<span style="display:none;">4. </span>
										<label>
											<input class="wpProQuiz_questionInput" autocomplete="off" type="radio" name="question_9_45" value="4"> כן, רק בדרכים עירוניות צפופות.										</label>

																		</li>
													</ul>
									</div>
									<div class="wpProQuiz_response" style="display: none;">
						<div style="display: none;" class="wpProQuiz_correct">
															<span>
								נכון								</span>
														<div class="wpProQuiz_AnswerMessage"></div>
						</div>
						<div style="display: none;" class="wpProQuiz_incorrect">
															<span>
								לא נכון							</span>
														<div class="wpProQuiz_AnswerMessage"></div>
						</div>
					</div>
				
									<div class="wpProQuiz_tipp" style="display: none; position: relative;">
						<div>
							<h5 style="margin: 0px 0px 10px;" class="wpProQuiz_header">
							רמז							</h5>
							<p>המרחב התעבורתי הוא מושג רחב הכולל בתוכו את כל מה שנמצא בדרך, את כל מי שמשתמש בדרך ואת כל מה שיש לו השפעה על הנסיעה בדרך.<br>
למרחב התעבורתי חברו ארבעה שותפים מרכזיים:</p>
<p>א. פני הדרך – כל מה שישנו בדרך ובסביבתה: מרחבים פתוחים, מרחבים בנויים, כבישים, מדרכות, תמרורים ורמזורים, ועוד. ב.עוברי הדרך – כל משתמשי הדרך הנמצאים בה לכל מטרה: להליכה, לרכיבה, לנסיעה ועוד. ג. כלי רכב – כל כלי הרכב הנעים בדרך על מאפייניהם וסוגיהם השונים. ד. הסביבה – כל תנאי שמשפיע על הנסיעה כגון: תנאי הנראות, שעות היום או הלילה או כמות הנוסעים בכביש.</p>
<p>כפי שתראו בתמונה, להקות בעלי חיים יכולות לנוע בצפיפות כגוף אחד מבלי להתנגש אחד בשני ובלי נפגעים.</p>
<p>שלושה מאפיינים עיקריים למרחב התעבורתי:</p>
<p>א. תנועה רבה ומהירה</p>
<p>ב. שונות ורבגוניות של משתמשי הדרך או של הרכבים הנעים בדרך, כגון השוני העצום שקיים בין רכב לבין אופנוע, או בין נהג ותיק ובעל ניסיון לנהג צעיר חדש חסר ניסיון.</p>
<p>ג. ריבוי מפגשים בין משתמשי הדרך – כל גורם הנע במרחב התעבורתי נתקל בדרכו במשתמשי דרך אחרים הנעים לצידו ומה שיקרה במפגש ביניהם תלוי באמצעי הזהירות שנקטו בהם.</p>
<p><span class="highlight-hint">נסכם ונאמר כי סכנות ואי וודאות רבה מאפיינות את המרחב התעבורתי בשל מאפייניו</span></p>
<p>מורכבותה של מטלת הנהיגה</p>
<p>הנהיגה היא מטלה מורכבת ומסובכת. תראו כמה פעולות על הנהג לבצע בזמן קצר: עליו לאסוף מידע על הסביבה. היות והדרך מתאפיינת בתנועה רבה ומהירה, בשונות גדולה בין משתתפי הדרך ובריבוי מפגשים ביניהם – פעולת איסוף המידע קשה במיוחד שהרי הסביבה משתנה או יכולה להשתנות בכל רגע.</p>
<p>משימה:</p>
<p>לפניכם סרטון הממחיש ומדגים את מורכבות מטלת הנהיגה ביום רגיל במנהטן. בתמונות דומות תתקלו גם בארצנו בערים הגדולות.</p>
<p>התוכלו להצביע על הרגעים בסרטון בהם הנהיגה מורכבת ומחייבת זהירות ועירנות רבה מצד הנהג? רשמו במהלך הצפייה לפחות 5 מצבים שדרשו מהנהג היערכות מיוחדת ותשומת לב מירבית.</p>
<p>הפנייה לסרטון מתוך “תורת החינוך התעבורתי” פרק 1 עמ` 11-12.</p>
<p>למורה: מומלץ מומלץ לעצור את הסרטון מפעם לפעם, לשתף את התלמידים ולהדגיש בפניהם את המורכבות של מצבי הנהיגה שראו בסרטון זה עתה.</p>
<p>מהירות התנועה היא נתון משפיע ביותר. פעמים רבות אירועים מתרחשים בקצב מהיר הרבה יותר ממה שנדרש לאדם באופן טבעי כדי להגיב להם. בנוסף, לכל נהג רצון משלו שמנוגד לעיתים לרצון חברו ופעמים רבות לנהגים אין רגישות מספקת לזולת ונהג צריך לקחת זאת בחשבון.</p>
<p>לכן נכון יהיה לחזור ולהזכיר שהמרחב התעבורתי מתאפיין באי ודאות ובסכנות רבות.</p>
<div class="btn-wrapper"><button id="mark-hint" type="button">סמן רמז</button><br>
<button id="close-hint" type="button">סגור רמז</button></div>
						</div>
					</div>
				
													<input type="button" name="next" value="הבא" class="wpProQuiz_button wpProQuiz_QuestionButton" style="float: left ; margin-right: 10px ; display: none;"> 													<input type="button" name="tip" value="רמז" class="wpProQuiz_button wpProQuiz_QuestionButton wpProQuiz_TipButton" style="float: left ; display: inline-block; margin-right: 10px ;"> 								<input type="button" name="check" value="סמן" class="wpProQuiz_button wpProQuiz_QuestionButton" style="float: right; margin-right: 10px;"> 								<input type="button" name="back" value="חזרה" class="wpProQuiz_button wpProQuiz_QuestionButton" style="float: right; display: none;"> 								<div style="clear: both;"></div>

							</li>

					<li class="wpProQuiz_listItem" style="display: none;" data-type="single" data-question-meta="{&quot;type&quot;:&quot;single&quot;,&quot;question_pro_id&quot;:46,&quot;question_post_id&quot;:1374}">
				<div class="wpProQuiz_question_page" style="display:none;">
				שאלה <span>6</span> מתוך <span>8</span>				</div>
				<h5 style="display: none;" class="wpProQuiz_header">
					<span>6</span>. שאלה
				</h5>

				
								<div class="wpProQuiz_question" style="margin: 10px 0px 0px 0px;">
					<div class="wpProQuiz_question_text">
						<p>מפגש בין עובר דרך לסביבה הוא:</p>
					</div>
					<p class="wpProQuiz_clear" style="clear:both;"></p>

										
										<ul class="wpProQuiz_questionList" data-question_id="46" data-type="single">
						
								<li class="wpProQuiz_questionListItem" data-pos="0">
																			<span style="display:none;">1. </span>
										<label>
											<input class="wpProQuiz_questionInput" autocomplete="off" type="radio" name="question_9_46" value="1"> מפגש בצומת מרומזר בין הולך רגל לנהג.										</label>

																		</li>
								
								<li class="wpProQuiz_questionListItem" data-pos="1">
																			<span style="display:none;">2. </span>
										<label>
											<input class="wpProQuiz_questionInput" autocomplete="off" type="radio" name="question_9_46" value="2"> מפגש בין תמרור להולך רגל.										</label>

																		</li>
								
								<li class="wpProQuiz_questionListItem" data-pos="2">
																			<span style="display:none;">3. </span>
										<label>
											<input class="wpProQuiz_questionInput" autocomplete="off" type="radio" name="question_9_46" value="3"> מפגש בין רוכב אופניים חשמליים לנהג.										</label>

																		</li>
								
								<li class="wpProQuiz_questionListItem" data-pos="3">
																			<span style="display:none;">4. </span>
										<label>
											<input class="wpProQuiz_questionInput" autocomplete="off" type="radio" name="question_9_46" value="4"> נהיגה בשעה שקרני השמש מסנוורות את הנהג.										</label>

																		</li>
													</ul>
									</div>
									<div class="wpProQuiz_response" style="display: none;">
						<div style="display: none;" class="wpProQuiz_correct">
															<span>
								נכון								</span>
														<div class="wpProQuiz_AnswerMessage"></div>
						</div>
						<div style="display: none;" class="wpProQuiz_incorrect">
															<span>
								לא נכון							</span>
														<div class="wpProQuiz_AnswerMessage"></div>
						</div>
					</div>
				
									<div class="wpProQuiz_tipp" style="display: none; position: relative;">
						<div>
							<h5 style="margin: 0px 0px 10px;" class="wpProQuiz_header">
							רמז							</h5>
							<p>המרחב התעבורתי הוא מושג רחב הכולל בתוכו את כל מה שנמצא בדרך, את כל מי שמשתמש בדרך ואת כל מה שיש לו השפעה על הנסיעה בדרך.<br>
למרחב התעבורתי חברו ארבעה שותפים מרכזיים:</p>
<p><span class="highlight-hint">א. פני הדרך – כל מה שישנו בדרך ובסביבתה: מרחבים פתוחים, מרחבים בנויים, כבישים, מדרכות, תמרורים ורמזורים, ועוד. ב.עוברי הדרך – כל משתמשי הדרך הנמצאים בה לכל מטרה: להליכה, לרכיבה, לנסיעה ועוד. ג. כלי רכב – כל כלי הרכב הנעים בדרך על מאפייניהם וסוגיהם השונים. ד. הסביבה – כל תנאי שמשפיע על הנסיעה כגון: תנאי הנראות, שעות היום או הלילה או כמות הנוסעים בכביש.</span></p>
<p>כפי שתראו בתמונה, להקות בעלי חיים יכולות לנוע בצפיפות כגוף אחד מבלי להתנגש אחד בשני ובלי נפגעים.</p>
<p>שלושה מאפיינים עיקריים למרחב התעבורתי:</p>
<p>א. תנועה רבה ומהירה</p>
<p>ב. שונות ורבגוניות של משתמשי הדרך או של הרכבים הנעים בדרך, כגון השוני העצום שקיים בין רכב לבין אופנוע, או בין נהג ותיק ובעל ניסיון לנהג צעיר חדש חסר ניסיון.</p>
<p>ג. ריבוי מפגשים בין משתמשי הדרך – כל גורם הנע במרחב התעבורתי נתקל בדרכו במשתמשי דרך אחרים הנעים לצידו ומה שיקרה במפגש ביניהם תלוי באמצעי הזהירות שנקטו בהם.</p>
<p>נסכם ונאמר כי סכנות ואי וודאות רבה מאפיינות את המרחב התעבורתי בשל מאפייניו</p>
<p>מורכבותה של מטלת הנהיגה</p>
<p>הנהיגה היא מטלה מורכבת ומסובכת. תראו כמה פעולות על הנהג לבצע בזמן קצר: עליו לאסוף מידע על הסביבה. היות והדרך מתאפיינת בתנועה רבה ומהירה, בשונות גדולה בין משתתפי הדרך ובריבוי מפגשים ביניהם – פעולת איסוף המידע קשה במיוחד שהרי הסביבה משתנה או יכולה להשתנות בכל רגע.</p>
<p>משימה:</p>
<p>לפניכם סרטון הממחיש ומדגים את מורכבות מטלת הנהיגה ביום רגיל במנהטן. בתמונות דומות תתקלו גם בארצנו בערים הגדולות.</p>
<p>התוכלו להצביע על הרגעים בסרטון בהם הנהיגה מורכבת ומחייבת זהירות ועירנות רבה מצד הנהג? רשמו במהלך הצפייה לפחות 5 מצבים שדרשו מהנהג היערכות מיוחדת ותשומת לב מירבית.</p>
<p>הפנייה לסרטון מתוך “תורת החינוך התעבורתי” פרק 1 עמ` 11-12.</p>
<p>למורה: מומלץ מומלץ לעצור את הסרטון מפעם לפעם, לשתף את התלמידים ולהדגיש בפניהם את המורכבות של מצבי הנהיגה שראו בסרטון זה עתה.</p>
<p>מהירות התנועה היא נתון משפיע ביותר. פעמים רבות אירועים מתרחשים בקצב מהיר הרבה יותר ממה שנדרש לאדם באופן טבעי כדי להגיב להם. בנוסף, לכל נהג רצון משלו שמנוגד לעיתים לרצון חברו ופעמים רבות לנהגים אין רגישות מספקת לזולת ונהג צריך לקחת זאת בחשבון.</p>
<p>לכן נכון יהיה לחזור ולהזכיר שהמרחב התעבורתי מתאפיין באי ודאות ובסכנות רבות.</p>
<div class="btn-wrapper"><button id="mark-hint" type="button">סמן רמז</button><br>
<button id="close-hint" type="button">סגור רמז</button></div>
						</div>
					</div>
				
													<input type="button" name="next" value="הבא" class="wpProQuiz_button wpProQuiz_QuestionButton" style="float: left ; margin-right: 10px ; display: none;"> 													<input type="button" name="tip" value="רמז" class="wpProQuiz_button wpProQuiz_QuestionButton wpProQuiz_TipButton" style="float: left ; display: inline-block; margin-right: 10px ;"> 								<input type="button" name="check" value="סמן" class="wpProQuiz_button wpProQuiz_QuestionButton" style="float: right; margin-right: 10px;"> 								<input type="button" name="back" value="חזרה" class="wpProQuiz_button wpProQuiz_QuestionButton" style="float: right; display: none;"> 								<div style="clear: both;"></div>

							</li>

					<li class="wpProQuiz_listItem" style="display: none;" data-type="single" data-question-meta="{&quot;type&quot;:&quot;single&quot;,&quot;question_pro_id&quot;:47,&quot;question_post_id&quot;:1375}">
				<div class="wpProQuiz_question_page" style="display:none;">
				שאלה <span>7</span> מתוך <span>8</span>				</div>
				<h5 style="display: none;" class="wpProQuiz_header">
					<span>7</span>. שאלה
				</h5>

				
								<div class="wpProQuiz_question" style="margin: 10px 0px 0px 0px;">
					<div class="wpProQuiz_question_text">
						<p>מפגש בין הדרך לעובר דרך הוא:</p>
					</div>
					<p class="wpProQuiz_clear" style="clear:both;"></p>

										
										<ul class="wpProQuiz_questionList" data-question_id="47" data-type="single">
						
								<li class="wpProQuiz_questionListItem" data-pos="0">
																			<span style="display:none;">1. </span>
										<label>
											<input class="wpProQuiz_questionInput" autocomplete="off" type="radio" name="question_9_47" value="1"> מפגש בצומת מרומזר בין הולך רגל לנהג.										</label>

																		</li>
								
								<li class="wpProQuiz_questionListItem" data-pos="1">
																			<span style="display:none;">2. </span>
										<label>
											<input class="wpProQuiz_questionInput" autocomplete="off" type="radio" name="question_9_47" value="2"> מפגש בשעות הלילה בין נהג להולך רגל.										</label>

																		</li>
								
								<li class="wpProQuiz_questionListItem" data-pos="2">
																			<span style="display:none;">3. </span>
										<label>
											<input class="wpProQuiz_questionInput" autocomplete="off" type="radio" name="question_9_47" value="3"> מפגש ביום גשום בין רוכב אופניים חשמליים לנהג.										</label>

																		</li>
								
								<li class="wpProQuiz_questionListItem" data-pos="3">
																			<span style="display:none;">4. </span>
										<label>
											<input class="wpProQuiz_questionInput" autocomplete="off" type="radio" name="question_9_47" value="4"> נהיגה בשעה שקרני השמש מסנוורות את הנהג.										</label>

																		</li>
													</ul>
									</div>
									<div class="wpProQuiz_response" style="display: none;">
						<div style="display: none;" class="wpProQuiz_correct">
															<span>
								נכון								</span>
														<div class="wpProQuiz_AnswerMessage"></div>
						</div>
						<div style="display: none;" class="wpProQuiz_incorrect">
															<span>
								לא נכון							</span>
														<div class="wpProQuiz_AnswerMessage"></div>
						</div>
					</div>
				
									<div class="wpProQuiz_tipp" style="display: none; position: relative;">
						<div>
							<h5 style="margin: 0px 0px 10px;" class="wpProQuiz_header">
							רמז							</h5>
							<p>המרחב התעבורתי הוא מושג רחב הכולל בתוכו את כל מה שנמצא בדרך, את כל מי שמשתמש בדרך ואת כל מה שיש לו השפעה על הנסיעה בדרך.<br>
למרחב התעבורתי חברו ארבעה שותפים מרכזיים:</p>
<p><span class="highlight-hint">א. פני הדרך – כל מה שישנו בדרך ובסביבתה: מרחבים פתוחים, מרחבים בנויים, כבישים, מדרכות, תמרורים ורמזורים, ועוד. ב.עוברי הדרך – כל משתמשי הדרך הנמצאים בה לכל מטרה: להליכה, לרכיבה, לנסיעה ועוד. ג. כלי רכב – כל כלי הרכב הנעים בדרך על מאפייניהם וסוגיהם השונים. ד. הסביבה – כל תנאי שמשפיע על הנסיעה כגון: תנאי הנראות, שעות היום או הלילה או כמות הנוסעים בכביש.</span></p>
<p>כפי שתראו בתמונה, להקות בעלי חיים יכולות לנוע בצפיפות כגוף אחד מבלי להתנגש אחד בשני ובלי נפגעים.</p>
<p>שלושה מאפיינים עיקריים למרחב התעבורתי:</p>
<p>א. תנועה רבה ומהירה</p>
<p>ב. שונות ורבגוניות של משתמשי הדרך או של הרכבים הנעים בדרך, כגון השוני העצום שקיים בין רכב לבין אופנוע, או בין נהג ותיק ובעל ניסיון לנהג צעיר חדש חסר ניסיון.</p>
<p>ג. ריבוי מפגשים בין משתמשי הדרך – כל גורם הנע במרחב התעבורתי נתקל בדרכו במשתמשי דרך אחרים הנעים לצידו ומה שיקרה במפגש ביניהם תלוי באמצעי הזהירות שנקטו בהם.</p>
<p>נסכם ונאמר כי סכנות ואי וודאות רבה מאפיינות את המרחב התעבורתי בשל מאפייניו</p>
<p>מורכבותה של מטלת הנהיגה</p>
<p>הנהיגה היא מטלה מורכבת ומסובכת. תראו כמה פעולות על הנהג לבצע בזמן קצר: עליו לאסוף מידע על הסביבה. היות והדרך מתאפיינת בתנועה רבה ומהירה, בשונות גדולה בין משתתפי הדרך ובריבוי מפגשים ביניהם – פעולת איסוף המידע קשה במיוחד שהרי הסביבה משתנה או יכולה להשתנות בכל רגע.</p>
<p>משימה:</p>
<p>לפניכם סרטון הממחיש ומדגים את מורכבות מטלת הנהיגה ביום רגיל במנהטן. בתמונות דומות תתקלו גם בארצנו בערים הגדולות.</p>
<p>התוכלו להצביע על הרגעים בסרטון בהם הנהיגה מורכבת ומחייבת זהירות ועירנות רבה מצד הנהג? רשמו במהלך הצפייה לפחות 5 מצבים שדרשו מהנהג היערכות מיוחדת ותשומת לב מירבית.</p>
<p>הפנייה לסרטון מתוך “תורת החינוך התעבורתי” פרק 1 עמ` 11-12.</p>
<p>למורה: מומלץ מומלץ לעצור את הסרטון מפעם לפעם, לשתף את התלמידים ולהדגיש בפניהם את המורכבות של מצבי הנהיגה שראו בסרטון זה עתה.</p>
<p>מהירות התנועה היא נתון משפיע ביותר. פעמים רבות אירועים מתרחשים בקצב מהיר הרבה יותר ממה שנדרש לאדם באופן טבעי כדי להגיב להם. בנוסף, לכל נהג רצון משלו שמנוגד לעיתים לרצון חברו ופעמים רבות לנהגים אין רגישות מספקת לזולת ונהג צריך לקחת זאת בחשבון.</p>
<p>לכן נכון יהיה לחזור ולהזכיר שהמרחב התעבורתי מתאפיין באי ודאות ובסכנות רבות.</p>
<div class="btn-wrapper"><button id="mark-hint" type="button">סמן רמז</button><br>
<button id="close-hint" type="button">סגור רמז</button></div>
						</div>
					</div>
				
													<input type="button" name="next" value="הבא" class="wpProQuiz_button wpProQuiz_QuestionButton" style="float: left ; margin-right: 10px ; display: none;"> 													<input type="button" name="tip" value="רמז" class="wpProQuiz_button wpProQuiz_QuestionButton wpProQuiz_TipButton" style="float: left ; display: inline-block; margin-right: 10px ;"> 								<input type="button" name="check" value="סמן" class="wpProQuiz_button wpProQuiz_QuestionButton" style="float: right; margin-right: 10px;"> 								<input type="button" name="back" value="חזרה" class="wpProQuiz_button wpProQuiz_QuestionButton" style="float: right; display: none;"> 								<div style="clear: both;"></div>

							</li>

					<li class="wpProQuiz_listItem" style="display: none;" data-type="single" data-question-meta="{&quot;type&quot;:&quot;single&quot;,&quot;question_pro_id&quot;:48,&quot;question_post_id&quot;:1376}">
				<div class="wpProQuiz_question_page" style="display:none;">
				שאלה <span>8</span> מתוך <span>8</span>				</div>
				<h5 style="display: none;" class="wpProQuiz_header">
					<span>8</span>. שאלה
				</h5>

				
								<div class="wpProQuiz_question" style="margin: 10px 0px 0px 0px;">
					<div class="wpProQuiz_question_text">
						<p>מהו "מרחב תעבורתי"?</p>
					</div>
					<p class="wpProQuiz_clear" style="clear:both;"></p>

										
										<ul class="wpProQuiz_questionList" data-question_id="48" data-type="single">
						
								<li class="wpProQuiz_questionListItem" data-pos="0">
																			<span style="display:none;">1. </span>
										<label>
											<input class="wpProQuiz_questionInput" autocomplete="off" type="radio" name="question_9_48" value="1"> מרחב תעבורתי הוא המרחב שבו כלי הרכב נעים בדרך.										</label>

																		</li>
								
								<li class="wpProQuiz_questionListItem" data-pos="1">
																			<span style="display:none;">2. </span>
										<label>
											<input class="wpProQuiz_questionInput" autocomplete="off" type="radio" name="question_9_48" value="2"> מרחב תעבורתי כולל את כל בני האדם המשתמשים בדרך.										</label>

																		</li>
								
								<li class="wpProQuiz_questionListItem" data-pos="2">
																			<span style="display:none;">3. </span>
										<label>
											<input class="wpProQuiz_questionInput" autocomplete="off" type="radio" name="question_9_48" value="3"> מרחב תעבורתי הוא מושג רחב הכולל את כל מי שנמצא בדרך ואת כל מי שמשתמש בדרך.										</label>

																		</li>
								
								<li class="wpProQuiz_questionListItem" data-pos="3">
																			<span style="display:none;">4. </span>
										<label>
											<input class="wpProQuiz_questionInput" autocomplete="off" type="radio" name="question_9_48" value="4"> מרחב תעבורתי הוא מושג רחב הכולל את כל מי שנמצא בדרך ואת כל מי שמשתמש בדרך, מלבד עגלות שאין להן מנוע.										</label>

																		</li>
													</ul>
									</div>
									<div class="wpProQuiz_response" style="display: none;">
						<div style="display: none;" class="wpProQuiz_correct">
															<span>
								נכון								</span>
														<div class="wpProQuiz_AnswerMessage"></div>
						</div>
						<div style="display: none;" class="wpProQuiz_incorrect">
															<span>
								לא נכון							</span>
														<div class="wpProQuiz_AnswerMessage"></div>
						</div>
					</div>
				
									<div class="wpProQuiz_tipp" style="display: none; position: relative;">
						<div>
							<h5 style="margin: 0px 0px 10px;" class="wpProQuiz_header">
							רמז							</h5>
							<p><span class="highlight-hint">המרחב התעבורתי הוא מושג רחב הכולל בתוכו את כל מה שנמצא בדרך, את כל מי שמשתמש בדרך ואת כל מה שיש לו השפעה על הנסיעה בדרך.</span><br>
למרחב התעבורתי חברו ארבעה שותפים מרכזיים:</p>
<p>א. פני הדרך – כל מה שישנו בדרך ובסביבתה: מרחבים פתוחים, מרחבים בנויים, כבישים, מדרכות, תמרורים ורמזורים, ועוד. ב.עוברי הדרך – כל משתמשי הדרך הנמצאים בה לכל מטרה: להליכה, לרכיבה, לנסיעה ועוד. ג. כלי רכב – כל כלי הרכב הנעים בדרך על מאפייניהם וסוגיהם השונים. ד. הסביבה – כל תנאי שמשפיע על הנסיעה כגון: תנאי הנראות, שעות היום או הלילה או כמות הנוסעים בכביש.</p>
<p>כפי שתראו בתמונה, להקות בעלי חיים יכולות לנוע בצפיפות כגוף אחד מבלי להתנגש אחד בשני ובלי נפגעים.</p>
<p>שלושה מאפיינים עיקריים למרחב התעבורתי:</p>
<p>א. תנועה רבה ומהירה</p>
<p>ב. שונות ורבגוניות של משתמשי הדרך או של הרכבים הנעים בדרך, כגון השוני העצום שקיים בין רכב לבין אופנוע, או בין נהג ותיק ובעל ניסיון לנהג צעיר חדש חסר ניסיון.</p>
<p>ג. ריבוי מפגשים בין משתמשי הדרך – כל גורם הנע במרחב התעבורתי נתקל בדרכו במשתמשי דרך אחרים הנעים לצידו ומה שיקרה במפגש ביניהם תלוי באמצעי הזהירות שנקטו בהם.</p>
<p>נסכם ונאמר כי סכנות ואי וודאות רבה מאפיינות את המרחב התעבורתי בשל מאפייניו</p>
<p>מורכבותה של מטלת הנהיגה</p>
<p>הנהיגה היא מטלה מורכבת ומסובכת. תראו כמה פעולות על הנהג לבצע בזמן קצר: עליו לאסוף מידע על הסביבה. היות והדרך מתאפיינת בתנועה רבה ומהירה, בשונות גדולה בין משתתפי הדרך ובריבוי מפגשים ביניהם – פעולת איסוף המידע קשה במיוחד שהרי הסביבה משתנה או יכולה להשתנות בכל רגע.</p>
<p>משימה:</p>
<p>לפניכם סרטון הממחיש ומדגים את מורכבות מטלת הנהיגה ביום רגיל במנהטן. בתמונות דומות תתקלו גם בארצנו בערים הגדולות.</p>
<p>התוכלו להצביע על הרגעים בסרטון בהם הנהיגה מורכבת ומחייבת זהירות ועירנות רבה מצד הנהג? רשמו במהלך הצפייה לפחות 5 מצבים שדרשו מהנהג היערכות מיוחדת ותשומת לב מירבית.</p>
<p>הפנייה לסרטון מתוך “תורת החינוך התעבורתי” פרק 1 עמ` 11-12.</p>
<p>למורה: מומלץ מומלץ לעצור את הסרטון מפעם לפעם, לשתף את התלמידים ולהדגיש בפניהם את המורכבות של מצבי הנהיגה שראו בסרטון זה עתה.</p>
<p>מהירות התנועה היא נתון משפיע ביותר. פעמים רבות אירועים מתרחשים בקצב מהיר הרבה יותר ממה שנדרש לאדם באופן טבעי כדי להגיב להם. בנוסף, לכל נהג רצון משלו שמנוגד לעיתים לרצון חברו ופעמים רבות לנהגים אין רגישות מספקת לזולת ונהג צריך לקחת זאת בחשבון.</p>
<p>לכן נכון יהיה לחזור ולהזכיר שהמרחב התעבורתי מתאפיין באי ודאות ובסכנות רבות.</p>
<div class="btn-wrapper"><button id="mark-hint" type="button">סמן רמז</button><br>
<button id="close-hint" type="button">סגור רמז</button></div>
						</div>
					</div>
				
													<input type="button" name="next" value="סיים מבחן" class="wpProQuiz_button wpProQuiz_QuestionButton" style="float: left ; margin-right: 10px ; display: none;"> 													<input type="button" name="tip" value="רמז" class="wpProQuiz_button wpProQuiz_QuestionButton wpProQuiz_TipButton" style="float: left ; display: inline-block; margin-right: 10px ;"> 								<input type="button" name="check" value="סמן" class="wpProQuiz_button wpProQuiz_QuestionButton" style="float: right; margin-right: 10px;"> 								<input type="button" name="back" value="חזרה" class="wpProQuiz_button wpProQuiz_QuestionButton" style="float: right; display: none;"> 								<div style="clear: both;"></div>

							</li>

			</ol>
	</div>
		</div>
		
</div> <!--/.learndash-wrapper-->
</div>
</div>
						</div>
				</div>

                +

                <div class="elementor-element elementor-element-e61956c elementor-widget elementor-widget-shortcode" data-id="e61956c" data-element_type="widget" data-widget_type="shortcode.default">
				<div class="elementor-widget-container">
							<div class="elementor-shortcode">ld_quiz quiz_id="1309"]
		<div class="wpProQuiz_content" id="wpProQuiz_7" data-quiz-meta="{&quot;quiz_pro_id&quot;:7,&quot;quiz_post_id&quot;:null}">
			<div class="wpProQuiz_spinner" style="display: none;">
				<div></div>
			</div>
			<div style="display: none;" class="wpProQuiz_time_limit">
	<div class="time">
		זמן מוגבל: <span>0</span>	</div>
	<div class="wpProQuiz_progress"></div>
</div>
<div class="wpProQuiz_checkPage" style="display: none;">
	<h4 class="wpProQuiz_header">
	תקציר המבחן	</h4>
	<p><span>0</span> מתוך 9 שאלות הושלמו</p>	<p>שאלות:</p>
	<div class="wpProQuiz_reviewSummary"></div>

	
	<input type="button" name="endQuizSummary" value="סיים מבחן" class="wpProQuiz_button"> </div>
<div class="wpProQuiz_infopage" style="display: none;">
	<h4>מידע</h4>
		<input type="button" name="endInfopage" value="סיים מבחן" class="wpProQuiz_button"> </div>
<div class="wpProQuiz_text" style="display: none;">
		<div>
		<input class="wpProQuiz_button" type="button" value="התחל מבחן" name="startQuiz">	</div>
</div>
<div style="display: none;" class="wpProQuiz_lock">		
	<p>כבר השלמת את המבחן בעבר. לכן אינך יכול להתחיל אותו שוב.</p></div>
<div style="display: none;" class="wpProQuiz_loadQuiz">
	<p>
		המבחן נטען...	</p>
</div>
<div style="display: none;" class="wpProQuiz_startOnlyRegisteredUser">
	<p>עליך להתחבר או להירשם כדי להתחיל את המבחן.</p></div>
<div style="display: none;" class="wpProQuiz_prerequisite">
	<p>אתה חייב להשלים קודם את הבאים: <span></span></p></div>
<div style="display: none;" class="wpProQuiz_sending">
	<h4 class="wpProQuiz_header">תוצאות</h4>
	<p>
		</p><div>
		מבחןהושלם. התוצאות נרשמות.		</div>
		<div>
			<dd class="course_progress">
				<div class="course_progress_blue sending_progress_bar" style="width: 0%;">
				</div>
			</dd>
		</div>
	<p></p>
</div>

<div style="display: none;" class="wpProQuiz_results">
	<h4 class="wpProQuiz_header">תוצאות</h4>
	<p><span class="wpProQuiz_correct_answer">0</span> מתוך <span>9</span> שאלות נענו נכון</p>		<p class="wpProQuiz_quiz_time">
		הזמן שלך: <span></span>		</p>
			<p class="wpProQuiz_time_limit_expired" style="display: none;">
	זמן חלף	</p>

			<p class="wpProQuiz_points">
		השגת <span>0</span> מתוך <span>0</span> נקודה(ות), (<span>0</span>)		</p>
		<p class="wpProQuiz_graded_points" style="display: none;">
		נקודה(ות) שקיבלת: <span>0</span> מתוך <span>0</span>, (<span>0</span>)		<br>
		<span>0</span> שאלות פתוחות בהמתנה (נקודה(ות) אפשרית(יות): <span>0</span>)		<br>
		</p>
		
	<div class="wpProQuiz_catOverview" style="display:none;">
		<h4>
		קטגוריות		</h4>

		<div style="margin-top: 10px;">
			<ol>
							<li data-category_id="0">
					<span class="wpProQuiz_catName">כללי</span>
					<span class="wpProQuiz_catPercent">0%</span>
				</li>
							</ol>
		</div>
	</div>
	<div>
		<ul class="wpProQuiz_resultsList">
							<li style="display: none;">
					<div>
											</div>
				</li>
					</ul>
	</div>
		<div class="ld-quiz-actions" style="margin: 10px 0px;">
				<div class="quiz_continue_link
				">

		</div>
					<input class="wpProQuiz_button wpProQuiz_button_restartQuiz" type="button" name="restartQuiz" value="התחל מבחן מחדש">						<input class="wpProQuiz_button wpProQuiz_button_reShowQuestion" type="button" name="reShowQuestion" value="הצג שאלות">					</div>
</div>
<div class="wpProQuiz_reviewDiv" style="">
	<div class="wpProQuiz_reviewQuestion">
	<ol style="margin-top: 0px !important">
					<li class="wpProQuiz_reviewQuestionSolved">1</li>
					<li class="wpProQuiz_reviewQuestionSolved">2</li>
					<li class="wpProQuiz_reviewQuestionSolved">3</li>
					<li class="wpProQuiz_reviewQuestionSolved">4</li>
					<li class="wpProQuiz_reviewQuestionTarget wpProQuiz_reviewQuestionSolved">5</li>
					<li>6</li>
					<li>7</li>
					<li>8</li>
					<li>9</li>
			</ol>
	<div style="display: none; top: 0px;"></div>
</div>
<div class="wpProQuiz_reviewLegend">
	<ol>
		<li class="learndash-quiz-review-legend-item-current">
			<span class="wpProQuiz_reviewColor wpProQuiz_reviewQuestion_Target"></span>
			<span class="wpProQuiz_reviewText">הנוכחי</span>
		</li>
		<li class="learndash-quiz-review-legend-item-review">
			<span class="wpProQuiz_reviewColor wpProQuiz_reviewColor_Review"></span>
			<span class="wpProQuiz_reviewText">ביקורת</span>
		</li>
		<li class="learndash-quiz-review-legend-item-answered">
			<span class="wpProQuiz_reviewColor wpProQuiz_reviewColor_Answer"></span>
			<span class="wpProQuiz_reviewText">נענו</span>
		</li>
		<li class="learndash-quiz-review-legend-item-correct">
			<span class="wpProQuiz_reviewColor wpProQuiz_reviewColor_AnswerCorrect"></span>
			<span class="wpProQuiz_reviewText">נכון</span>
		</li>
		<li class="learndash-quiz-review-legend-item-incorrect">
			<span class="wpProQuiz_reviewColor wpProQuiz_reviewColor_AnswerIncorrect"></span>
			<span class="wpProQuiz_reviewText">לא נכון</span>
		</li>
	</ol>
	<div style="clear: both;"></div>
</div>
<div class="wpProQuiz_reviewButtons">
			<input type="button" name="review" value="סקור שאלה" class="wpProQuiz_button2" style="float: left; display: block;"> 				<div style="clear: both;"></div>
	</div>
</div>
<div class="wpProQuiz_quizAnker" style="display: none;"></div>
<div style="" class="wpProQuiz_quiz">
	<ol class="wpProQuiz_list">
					<li class="wpProQuiz_listItem" style="display: none;" data-type="single" data-question-meta="{&quot;type&quot;:&quot;single&quot;,&quot;question_pro_id&quot;:30,&quot;question_post_id&quot;:0}">
				<div class="wpProQuiz_question_page" style="display:none;">
				שאלה <span>1</span> מתוך <span>9</span>				</div>
				<h5 style="display: none;" class="wpProQuiz_header">
					<span>1</span>. שאלה
				</h5>

				
								<div class="wpProQuiz_question" style="margin: 10px 0px 0px 0px;">
					<div class="wpProQuiz_question_text">
						<p>מיהו "עובר דרך"?</p>
					</div>
					<p class="wpProQuiz_clear" style="clear:both;"></p>

										
										<ul class="wpProQuiz_questionList" data-question_id="30" data-type="single">
						
								<li class="wpProQuiz_questionListItem" data-pos="0">
																			<span style="display:none;">1. </span>
										<label>
											<input class="wpProQuiz_questionInput" autocomplete="off" type="radio" name="question_7_30" value="1"> המשתמש בכביש לרכיבה על אופניים בלבד.
										</label>

																		</li>
								
								<li class="wpProQuiz_questionListItem" data-pos="1">
																			<span style="display:none;">2. </span>
										<label>
											<input class="wpProQuiz_questionInput" autocomplete="off" type="radio" name="question_7_30" value="2"> המשתמש בדרך לנסיעה ברכב מנועי בלבד.										</label>

																		</li>
								
								<li class="wpProQuiz_questionListItem" data-pos="2">
																			<span style="display:none;">3. </span>
										<label>
											<input class="wpProQuiz_questionInput" autocomplete="off" type="radio" name="question_7_30" value="3"> המשתמש בדרך לעמידה או לריצה בלבד.										</label>

																		</li>
								
								<li class="wpProQuiz_questionListItem" data-pos="3">
																			<span style="display:none;">4. </span>
										<label>
											<input class="wpProQuiz_questionInput" autocomplete="off" type="radio" name="question_7_30" value="4"> המשתמש בדרך לנסיעה, להליכה, לעמידה או לכל מטרה אחרת.										</label>

																		</li>
													</ul>
									</div>
									<div class="wpProQuiz_response" style="display: none;">
						<div style="display: none;" class="wpProQuiz_correct">
															<span>
								נכון								</span>
														<div class="wpProQuiz_AnswerMessage"></div>
						</div>
						<div style="display: none;" class="wpProQuiz_incorrect">
															<span>
								לא נכון							</span>
														<div class="wpProQuiz_AnswerMessage"></div>
						</div>
					</div>
				
									<div class="wpProQuiz_tipp" style="display: none; position: relative;">
						<div>
							<h5 style="margin: 0px 0px 10px;" class="wpProQuiz_header">
							רמז							</h5>
							<p>המרחב התעבורתי הוא מושג רחב הכולל בתוכו את כל מה שנמצא בדרך, את כל מי שמשתמש בדרך ואת כל מה שיש לו השפעה על הנסיעה בדרך.<br>למרחב התעבורתי חברו ארבעה שותפים מרכזיים:</p>
<p>א. פני הדרך – כל מה שישנו בדרך ובסביבתה: מרחבים פתוחים, מרחבים בנויים, כבישים, מדרכות, תמרורים ורמזורים, ועוד. ב. <span class="highlight-hint">עוברי הדרך – כל משתמשי הדרך הנמצאים בה לכל מטרה: להליכה, לרכיבה, לנסיעה ועוד. ג. כלי רכב – כל כלי הרכב הנעים בדרך על מאפייניהם וסוגיהם השונים. ד. הסביבה – כל תנאי שמשפיע על הנסיעה כגון: תנאי הנראות, שעות היום או הלילה או כמות הנוסעים בכביש.<br></span></p>
<p>כפי שתראו בתמונה, להקות בעלי חיים יכולות לנוע בצפיפות כגוף אחד מבלי להתנגש אחד בשני ובלי נפגעים.</p>
<p>שלושה מאפיינים עיקריים למרחב התעבורתי:</p>
<p>א. תנועה רבה ומהירה</p>
<p>ב. שונות ורבגוניות של משתמשי הדרך או של הרכבים הנעים בדרך, כגון השוני העצום שקיים בין רכב לבין אופנוע, או בין נהג ותיק ובעל ניסיון לנהג צעיר חדש חסר ניסיון.</p>
<p>ג. ריבוי מפגשים בין משתמשי הדרך – כל גורם הנע במרחב התעבורתי נתקל בדרכו במשתמשי דרך אחרים הנעים לצידו ומה שיקרה במפגש ביניהם תלוי באמצעי הזהירות שנקטו בהם.</p>
<p>נסכם ונאמר כי סכנות ואי וודאות רבה מאפיינות את המרחב התעבורתי בשל מאפייניו</p>
<p>מורכבותה של מטלת הנהיגה</p>
<p>הנהיגה היא מטלה מורכבת ומסובכת. תראו כמה פעולות על הנהג לבצע בזמן קצר: עליו לאסוף מידע על הסביבה. היות והדרך מתאפיינת בתנועה רבה ומהירה, בשונות גדולה בין משתתפי הדרך ובריבוי מפגשים ביניהם – פעולת איסוף המידע קשה במיוחד שהרי הסביבה משתנה או יכולה להשתנות בכל רגע.</p>
<p>משימה:</p>
<p>לפניכם סרטון הממחיש ומדגים את מורכבות מטלת הנהיגה ביום רגיל במנהטן. בתמונות דומות תתקלו גם בארצנו בערים הגדולות.</p>
<p>התוכלו להצביע על הרגעים בסרטון בהם הנהיגה מורכבת ומחייבת זהירות ועירנות רבה מצד הנהג? רשמו במהלך הצפייה לפחות 5 מצבים שדרשו מהנהג היערכות מיוחדת ותשומת לב מירבית.</p>
<p>הפנייה לסרטון מתוך “תורת החינוך התעבורתי” פרק 1 עמ` 11-12.</p>
<p>למורה: מומלץ מומלץ לעצור את הסרטון מפעם לפעם, לשתף את התלמידים ולהדגיש בפניהם את המורכבות של מצבי הנהיגה שראו בסרטון זה עתה.</p>
<p>מהירות התנועה היא נתון משפיע ביותר. פעמים רבות אירועים מתרחשים בקצב מהיר הרבה יותר ממה שנדרש לאדם באופן טבעי כדי להגיב להם. בנוסף, לכל נהג רצון משלו שמנוגד לעיתים לרצון חברו ופעמים רבות לנהגים אין רגישות מספקת לזולת ונהג צריך לקחת זאת בחשבון.</p>
<p>לכן נכון יהיה לחזור ולהזכיר שהמרחב התעבורתי מתאפיין באי ודאות ובסכנות רבות.</p>
<div class="btn-wrapper"><button id="mark-hint" type="button">סמן רמז</button><br><button id="close-hint" type="button">סגור רמז</button></div>
						</div>
					</div>
				
													<input type="button" name="next" value="הבא" class="wpProQuiz_button wpProQuiz_QuestionButton" style="float: left ; margin-right: 10px ; display: none;"> 													<input type="button" name="tip" value="רמז" class="wpProQuiz_button wpProQuiz_QuestionButton wpProQuiz_TipButton" style="float: left ; display: inline-block; margin-right: 10px ;"> 								<input type="button" name="check" value="סמן" class="wpProQuiz_button wpProQuiz_QuestionButton" style="float: right; margin-right: 10px;"> 								<input type="button" name="back" value="חזרה" class="wpProQuiz_button wpProQuiz_QuestionButton" style="float: right; display: none;"> 								<div style="clear: both;"></div>

							</li>

					<li class="wpProQuiz_listItem" style="display: none;" data-type="single" data-question-meta="{&quot;type&quot;:&quot;single&quot;,&quot;question_pro_id&quot;:31,&quot;question_post_id&quot;:0}">
				<div class="wpProQuiz_question_page" style="display:none;">
				שאלה <span>2</span> מתוך <span>9</span>				</div>
				<h5 style="display: none;" class="wpProQuiz_header">
					<span>2</span>. שאלה
				</h5>

				
								<div class="wpProQuiz_question" style="margin: 10px 0px 0px 0px;">
					<div class="wpProQuiz_question_text">
						<p>מהם מרכיבי ה"מרחב התעבורתי"?</p>
					</div>
					<p class="wpProQuiz_clear" style="clear:both;"></p>

										
										<ul class="wpProQuiz_questionList" data-question_id="31" data-type="single">
						
								<li class="wpProQuiz_questionListItem" data-pos="0">
																			<span style="display:none;">1. </span>
										<label>
											<input class="wpProQuiz_questionInput" autocomplete="off" type="radio" name="question_7_31" value="1" disabled="disabled"> כל מה שנמצא בעולם, כולל הרכוש ומזג האוויר שבתוך הבתים.										</label>

																		</li>
								
								<li class="wpProQuiz_questionListItem" data-pos="1">
																			<span style="display:none;">2. </span>
										<label>
											<input class="wpProQuiz_questionInput" autocomplete="off" type="radio" name="question_7_31" value="2" disabled="disabled"> כל מה שנמצא בדרך וכל מי שמשתמש בדרך: פני הדרך, עוברי דרך, כלי הרכב ותנאי הסביבה.										</label>

																		</li>
								
								<li class="wpProQuiz_questionListItem" data-pos="2">
																			<span style="display:none;">3. </span>
										<label>
											<input class="wpProQuiz_questionInput" autocomplete="off" type="radio" name="question_7_31" value="3" disabled="disabled"> מרכיבים ששייכים לעולם התעבורה בלבד: עוברי דרך וכלי רכב.										</label>

																		</li>
								
								<li class="wpProQuiz_questionListItem" data-pos="3">
																			<span style="display:none;">4. </span>
										<label>
											<input class="wpProQuiz_questionInput" autocomplete="off" type="radio" name="question_7_31" value="4" disabled="disabled"> מרכיבים ששייכים למרחב בלבד: פני הדרך ותנאי הסביבה.										</label>

																		</li>
													</ul>
									</div>
									<div class="wpProQuiz_response" style="display: none;">
						<div style="display: none;" class="wpProQuiz_correct">
															<span>
								נכון								</span>
														<div class="wpProQuiz_AnswerMessage"></div>
						</div>
						<div style="display: none;" class="wpProQuiz_incorrect">
															<span>
								לא נכון							</span>
														<div class="wpProQuiz_AnswerMessage"></div>
						</div>
					</div>
				
									<div class="wpProQuiz_tipp" style="display: none; position: relative;">
						<div>
							<h5 style="margin: 0px 0px 10px;" class="wpProQuiz_header">
							רמז							</h5>
							<p>המרחב התעבורתי הוא מושג רחב הכולל בתוכו את כל מה שנמצא בדרך, את כל מי שמשתמש בדרך ואת כל מה שיש לו השפעה על הנסיעה בדרך.<br>
למרחב התעבורתי חברו ארבעה שותפים מרכזיים:</p>
<p><span class="highlight-hint">א. פני הדרך – כל מה שישנו בדרך ובסביבתה: מרחבים פתוחים, מרחבים בנויים, כבישים, מדרכות, תמרורים ורמזורים, ועוד. ב. עוברי הדרך – כל משתמשי הדרך הנמצאים בה לכל מטרה: להליכה, לרכיבה, לנסיעה ועוד. ג. כלי רכב – כל כלי הרכב הנעים בדרך על מאפייניהם וסוגיהם השונים. ד. הסביבה – כל תנאי שמשפיע על הנסיעה כגון: תנאי הנראות, שעות היום או הלילה או כמות הנוסעים בכביש.</span></p>
<p>כפי שתראו בתמונה, להקות בעלי חיים יכולות לנוע בצפיפות כגוף אחד מבלי להתנגש אחד בשני ובלי נפגעים.</p>
<p>שלושה מאפיינים עיקריים למרחב התעבורתי:</p>
<p>א. תנועה רבה ומהירה</p>
<p>ב. שונות ורבגוניות של משתמשי הדרך או של הרכבים הנעים בדרך, כגון השוני העצום שקיים בין רכב לבין אופנוע, או בין נהג ותיק ובעל ניסיון לנהג צעיר חדש חסר ניסיון.</p>
<p>ג. ריבוי מפגשים בין משתמשי הדרך – כל גורם הנע במרחב התעבורתי נתקל בדרכו במשתמשי דרך אחרים הנעים לצידו ומה שיקרה במפגש ביניהם תלוי באמצעי הזהירות שנקטו בהם.</p>
<p>נסכם ונאמר כי סכנות ואי וודאות רבה מאפיינות את המרחב התעבורתי בשל מאפייניו</p>
<p>מורכבותה של מטלת הנהיגה</p>
<p>הנהיגה היא מטלה מורכבת ומסובכת. תראו כמה פעולות על הנהג לבצע בזמן קצר: עליו לאסוף מידע על הסביבה. היות והדרך מתאפיינת בתנועה רבה ומהירה, בשונות גדולה בין משתתפי הדרך ובריבוי מפגשים ביניהם – פעולת איסוף המידע קשה במיוחד שהרי הסביבה משתנה או יכולה להשתנות בכל רגע.</p>
<p>משימה:</p>
<p>לפניכם סרטון הממחיש ומדגים את מורכבות מטלת הנהיגה ביום רגיל במנהטן. בתמונות דומות תתקלו גם בארצנו בערים הגדולות.</p>
<p>התוכלו להצביע על הרגעים בסרטון בהם הנהיגה מורכבת ומחייבת זהירות ועירנות רבה מצד הנהג? רשמו במהלך הצפייה לפחות 5 מצבים שדרשו מהנהג היערכות מיוחדת ותשומת לב מירבית.</p>
<p>הפנייה לסרטון מתוך “תורת החינוך התעבורתי” פרק 1 עמ` 11-12.</p>
<p>למורה: מומלץ מומלץ לעצור את הסרטון מפעם לפעם, לשתף את התלמידים ולהדגיש בפניהם את המורכבות של מצבי הנהיגה שראו בסרטון זה עתה.</p>
<p>מהירות התנועה היא נתון משפיע ביותר. פעמים רבות אירועים מתרחשים בקצב מהיר הרבה יותר ממה שנדרש לאדם באופן טבעי כדי להגיב להם. בנוסף, לכל נהג רצון משלו שמנוגד לעיתים לרצון חברו ופעמים רבות לנהגים אין רגישות מספקת לזולת ונהג צריך לקחת זאת בחשבון.</p>
<p>לכן נכון יהיה לחזור ולהזכיר שהמרחב התעבורתי מתאפיין באי ודאות ובסכנות רבות.</p>
<div class="btn-wrapper"><button id="mark-hint" type="button">סמן רמז</button><br>
<button id="close-hint" type="button">סגור רמז</button></div>
						</div>
					</div>
				
													<input type="button" name="next" value="הבא" class="wpProQuiz_button wpProQuiz_QuestionButton" style="float: left ; margin-right: 10px ; display: none;"> 													<input type="button" name="tip" value="רמז" class="wpProQuiz_button wpProQuiz_QuestionButton wpProQuiz_TipButton" style="float: left ; display: inline-block; margin-right: 10px ;"> 								<input type="button" name="check" value="סמן" class="wpProQuiz_button wpProQuiz_QuestionButton" style="float: right; margin-right: 10px;"> 								<input type="button" name="back" value="חזרה" class="wpProQuiz_button wpProQuiz_QuestionButton" style="float: right; display: none;"> 								<div style="clear: both;"></div>

							</li>

					<li class="wpProQuiz_listItem" style="display: none;" data-type="single" data-question-meta="{&quot;type&quot;:&quot;single&quot;,&quot;question_pro_id&quot;:32,&quot;question_post_id&quot;:0}">
				<div class="wpProQuiz_question_page" style="display:none;">
				שאלה <span>3</span> מתוך <span>9</span>				</div>
				<h5 style="display: none;" class="wpProQuiz_header">
					<span>3</span>. שאלה
				</h5>

				
								<div class="wpProQuiz_question" style="margin: 10px 0px 0px 0px;">
					<div class="wpProQuiz_question_text">
						<p>במרחב התעבורתי מתקיימים מפגשים רבים בין עוברי דרך בהם עליהם להתחשב אחד בשני. נכון או לא נכון?</p>
					</div>
					<p class="wpProQuiz_clear" style="clear:both;"></p>

										
										<ul class="wpProQuiz_questionList" data-question_id="32" data-type="single">
						
								<li class="wpProQuiz_questionListItem" data-pos="0">
																			<span style="display:none;">1. </span>
										<label>
											<input class="wpProQuiz_questionInput" autocomplete="off" type="radio" name="question_7_32" value="1" disabled="disabled"> לא נכון. אם עוברי הדרך ינהגו לפי הוראות החוק לא יתקיימו נקודות מגע ביניהם.										</label>

																		</li>
								
								<li class="wpProQuiz_questionListItem" data-pos="1">
																			<span style="display:none;">2. </span>
										<label>
											<input class="wpProQuiz_questionInput" autocomplete="off" type="radio" name="question_7_32" value="2" disabled="disabled"> לא נכון, בכל מקרה במרחב התעבורתי אין מפגשים בין עוברי דרך.										</label>

																		</li>
								
								<li class="wpProQuiz_questionListItem" data-pos="2">
																			<span style="display:none;">3. </span>
										<label>
											<input class="wpProQuiz_questionInput" autocomplete="off" type="radio" name="question_7_32" value="3" disabled="disabled"> לא נכון, כל אחד ממשתמשי הדרך נע בנתיב שלו ולא נפגש עם אחרים.										</label>

																		</li>
								
								<li class="wpProQuiz_questionListItem" data-pos="3">
																			<span style="display:none;">4. </span>
										<label>
											<input class="wpProQuiz_questionInput" autocomplete="off" type="radio" name="question_7_32" value="4" disabled="disabled"> נכון, מפגשים מתקיימים במרחב התעבורתי בכל שעות היום ובכל מקום בדרך.										</label>

																		</li>
													</ul>
									</div>
									<div class="wpProQuiz_response" style="display: none;">
						<div style="display: none;" class="wpProQuiz_correct">
															<span>
								נכון								</span>
														<div class="wpProQuiz_AnswerMessage"></div>
						</div>
						<div style="display: none;" class="wpProQuiz_incorrect">
															<span>
								לא נכון							</span>
														<div class="wpProQuiz_AnswerMessage"></div>
						</div>
					</div>
				
									<div class="wpProQuiz_tipp" style="display: none; position: relative;">
						<div>
							<h5 style="margin: 0px 0px 10px;" class="wpProQuiz_header">
							רמז							</h5>
							<p>המרחב התעבורתי הוא מושג רחב הכולל בתוכו את כל מה שנמצא בדרך, את כל מי שמשתמש בדרך ואת כל מה שיש לו השפעה על הנסיעה בדרך.<br>
למרחב התעבורתי חברו ארבעה שותפים מרכזיים:</p>
<p>א. פני הדרך – כל מה שישנו בדרך ובסביבתה: מרחבים פתוחים, מרחבים בנויים, כבישים, מדרכות, תמרורים ורמזורים, ועוד. ב.עוברי הדרך – כל משתמשי הדרך הנמצאים בה לכל מטרה: להליכה, לרכיבה, לנסיעה ועוד. ג. כלי רכב – כל כלי הרכב הנעים בדרך על מאפייניהם וסוגיהם השונים. ד. הסביבה – כל תנאי שמשפיע על הנסיעה כגון: תנאי הנראות, שעות היום או הלילה או כמות הנוסעים בכביש.</p>
<p>כפי שתראו בתמונה, להקות בעלי חיים יכולות לנוע בצפיפות כגוף אחד מבלי להתנגש אחד בשני ובלי נפגעים.</p>
<p>שלושה מאפיינים עיקריים למרחב התעבורתי:</p>
<p>א. תנועה רבה ומהירה</p>
<p>ב. שונות ורבגוניות של משתמשי הדרך או של הרכבים הנעים בדרך, כגון השוני העצום שקיים בין רכב לבין אופנוע, או בין נהג ותיק ובעל ניסיון לנהג צעיר חדש חסר ניסיון.</p>
<p>ג. <span class="highlight-hint">ריבוי מפגשים בין משתמשי הדרך – כל גורם הנע במרחב התעבורתי נתקל בדרכו במשתמשי דרך אחרים הנעים לצידו ומה שיקרה במפגש ביניהם תלוי באמצעי הזהירות שנקטו בהם.</span></p>
<p>נסכם ונאמר כי סכנות ואי וודאות רבה מאפיינות את המרחב התעבורתי בשל מאפייניו</p>
<p>מורכבותה של מטלת הנהיגה</p>
<p>הנהיגה היא מטלה מורכבת ומסובכת. תראו כמה פעולות על הנהג לבצע בזמן קצר: עליו לאסוף מידע על הסביבה. היות והדרך מתאפיינת בתנועה רבה ומהירה, בשונות גדולה בין משתתפי הדרך ובריבוי מפגשים ביניהם – פעולת איסוף המידע קשה במיוחד שהרי הסביבה משתנה או יכולה להשתנות בכל רגע.</p>
<p>משימה:</p>
<p>לפניכם סרטון הממחיש ומדגים את מורכבות מטלת הנהיגה ביום רגיל במנהטן. בתמונות דומות תתקלו גם בארצנו בערים הגדולות.</p>
<p>התוכלו להצביע על הרגעים בסרטון בהם הנהיגה מורכבת ומחייבת זהירות ועירנות רבה מצד הנהג? רשמו במהלך הצפייה לפחות 5 מצבים שדרשו מהנהג היערכות מיוחדת ותשומת לב מירבית.</p>
<p>הפנייה לסרטון מתוך “תורת החינוך התעבורתי” פרק 1 עמ` 11-12.</p>
<p>למורה: מומלץ מומלץ לעצור את הסרטון מפעם לפעם, לשתף את התלמידים ולהדגיש בפניהם את המורכבות של מצבי הנהיגה שראו בסרטון זה עתה.</p>
<p>מהירות התנועה היא נתון משפיע ביותר. פעמים רבות אירועים מתרחשים בקצב מהיר הרבה יותר ממה שנדרש לאדם באופן טבעי כדי להגיב להם. בנוסף, לכל נהג רצון משלו שמנוגד לעיתים לרצון חברו ופעמים רבות לנהגים אין רגישות מספקת לזולת ונהג צריך לקחת זאת בחשבון.</p>
<p>לכן נכון יהיה לחזור ולהזכיר שהמרחב התעבורתי מתאפיין באי ודאות ובסכנות רבות.</p>
<div class="btn-wrapper"><button id="mark-hint" type="button">סמן רמז</button><br>
<button id="close-hint" type="button">סגור רמז</button></div>
						</div>
					</div>
				
													<input type="button" name="next" value="הבא" class="wpProQuiz_button wpProQuiz_QuestionButton" style="float: left ; margin-right: 10px ; display: none;"> 													<input type="button" name="tip" value="רמז" class="wpProQuiz_button wpProQuiz_QuestionButton wpProQuiz_TipButton" style="float: left ; display: inline-block; margin-right: 10px ;"> 								<input type="button" name="check" value="סמן" class="wpProQuiz_button wpProQuiz_QuestionButton" style="float: right; margin-right: 10px;"> 								<input type="button" name="back" value="חזרה" class="wpProQuiz_button wpProQuiz_QuestionButton" style="float: right; display: none;"> 								<div style="clear: both;"></div>

							</li>

					<li class="wpProQuiz_listItem" style="display: none;" data-type="single" data-question-meta="{&quot;type&quot;:&quot;single&quot;,&quot;question_pro_id&quot;:33,&quot;question_post_id&quot;:0}">
				<div class="wpProQuiz_question_page" style="display:none;">
				שאלה <span>4</span> מתוך <span>9</span>				</div>
				<h5 style="display: none;" class="wpProQuiz_header">
					<span>4</span>. שאלה
				</h5>

				
								<div class="wpProQuiz_question" style="margin: 10px 0px 0px 0px;">
					<div class="wpProQuiz_question_text">
						<p>הנהיגה היא משימה מורכבת. נכון או לא נכון?</p>
					</div>
					<p class="wpProQuiz_clear" style="clear:both;"></p>

										
										<ul class="wpProQuiz_questionList" data-question_id="33" data-type="single">
						
								<li class="wpProQuiz_questionListItem" data-pos="0">
																			<span style="display:none;">1. </span>
										<label>
											<input class="wpProQuiz_questionInput" autocomplete="off" type="radio" name="question_7_33" value="1" disabled="disabled"> לא נכון. רק כשיש עומס בדרכים לפעמים קשה לנהוג.										</label>

																		</li>
								
								<li class="wpProQuiz_questionListItem" data-pos="1">
																			<span style="display:none;">2. </span>
										<label>
											<input class="wpProQuiz_questionInput" autocomplete="off" type="radio" name="question_7_33" value="2" disabled="disabled"> לא נכון. רק נהגי משאיות כבדות מתעייפים בנהיגה בגלל משאם הכבד.										</label>

																		</li>
								
								<li class="wpProQuiz_questionListItem" data-pos="2">
																			<span style="display:none;">3. </span>
										<label>
											<input class="wpProQuiz_questionInput" autocomplete="off" type="radio" name="question_7_33" value="3" disabled="disabled"> נכון. מטלת הנהיגה דורשת ביצוע מספר מטלות במקביל ובזמן קצר וזה מורכב.										</label>

																		</li>
								
								<li class="wpProQuiz_questionListItem" data-pos="3">
																			<span style="display:none;">4. </span>
										<label>
											<input class="wpProQuiz_questionInput" autocomplete="off" type="radio" name="question_7_33" value="4" disabled="disabled"> נכון. אבל רק בגלל שלנהגים אין סבלנות והם לא מעניקים זכות קדימה כנדרש בחוק.										</label>

																		</li>
													</ul>
									</div>
									<div class="wpProQuiz_response" style="display: none;">
						<div style="display: none;" class="wpProQuiz_correct">
															<span>
								נכון								</span>
														<div class="wpProQuiz_AnswerMessage"></div>
						</div>
						<div style="display: none;" class="wpProQuiz_incorrect">
															<span>
								לא נכון							</span>
														<div class="wpProQuiz_AnswerMessage"></div>
						</div>
					</div>
				
									<div class="wpProQuiz_tipp" style="display: none; position: relative;">
						<div>
							<h5 style="margin: 0px 0px 10px;" class="wpProQuiz_header">
							רמז							</h5>
							<p>המרחב התעבורתי הוא מושג רחב הכולל בתוכו את כל מה שנמצא בדרך, את כל מי שמשתמש בדרך ואת כל מה שיש לו השפעה על הנסיעה בדרך.<br>
למרחב התעבורתי חברו ארבעה שותפים מרכזיים:</p>
<p>א. פני הדרך – כל מה שישנו בדרך ובסביבתה: מרחבים פתוחים, מרחבים בנויים, כבישים, מדרכות, תמרורים ורמזורים, ועוד. ב. עוברי הדרך – כל משתמשי הדרך הנמצאים בה לכל מטרה: להליכה, לרכיבה, לנסיעה ועוד. ג. כלי רכב – כל כלי הרכב הנעים בדרך על מאפייניהם וסוגיהם השונים. ד. הסביבה – כל תנאי שמשפיע על הנסיעה כגון: תנאי הנראות, שעות היום או הלילה או כמות הנוסעים בכביש</p>
<p>כפי שתראו בתמונה, להקות בעלי חיים יכולות לנוע בצפיפות כגוף אחד מבלי להתנגש אחד בשני ובלי נפגעים.</p>
<p>שלושה מאפיינים עיקריים למרחב התעבורתי:</p>
<p>א. תנועה רבה ומהירה</p>
<p>ב. שונות ורבגוניות של משתמשי הדרך או של הרכבים הנעים בדרך, כגון השוני העצום שקיים בין רכב לבין אופנוע, או בין נהג ותיק ובעל ניסיון לנהג צעיר חדש חסר ניסיון.</p>
<p>ג. ריבוי מפגשים בין משתמשי הדרך – כל גורם הנע במרחב התעבורתי נתקל בדרכו במשתמשי דרך אחרים הנעים לצידו ומה שיקרה במפגש ביניהם תלוי באמצעי הזהירות שנקטו בהם.</p>
<p>נסכם ונאמר כי סכנות ואי וודאות רבה מאפיינות את המרחב התעבורתי בשל מאפייניו</p>
<p>מורכבותה של מטלת הנהיגה</p>
<p><span class="highlight-hint">הנהיגה היא מטלה מורכבת ומסובכת. תראו כמה פעולות על הנהג לבצע בזמן קצר: עליו לאסוף מידע על הסביבה. היות והדרך מתאפיינת בתנועה רבה ומהירה, בשונות גדולה בין משתתפי הדרך ובריבוי מפגשים ביניהם – פעולת איסוף המידע קשה במיוחד שהרי הסביבה משתנה או יכולה להשתנות בכל רגע.</span></p>
<p>משימה:</p>
<p>לפניכם סרטון הממחיש ומדגים את מורכבות מטלת הנהיגה ביום רגיל במנהטן. בתמונות דומות תתקלו גם בארצנו בערים הגדולות.</p>
<p>התוכלו להצביע על הרגעים בסרטון בהם הנהיגה מורכבת ומחייבת זהירות ועירנות רבה מצד הנהג? רשמו במהלך הצפייה לפחות 5 מצבים שדרשו מהנהג היערכות מיוחדת ותשומת לב מירבית.</p>
<p>הפנייה לסרטון מתוך “תורת החינוך התעבורתי” פרק 1 עמ` 11-12.</p>
<p>למורה: מומלץ מומלץ לעצור את הסרטון מפעם לפעם, לשתף את התלמידים ולהדגיש בפניהם את המורכבות של מצבי הנהיגה שראו בסרטון זה עתה.</p>
<p>מהירות התנועה היא נתון משפיע ביותר. פעמים רבות אירועים מתרחשים בקצב מהיר הרבה יותר ממה שנדרש לאדם באופן טבעי כדי להגיב להם. בנוסף, לכל נהג רצון משלו שמנוגד לעיתים לרצון חברו ופעמים רבות לנהגים אין רגישות מספקת לזולת ונהג צריך לקחת זאת בחשבון.</p>
<p>לכן נכון יהיה לחזור ולהזכיר שהמרחב התעבורתי מתאפיין באי ודאות ובסכנות רבות.</p>
<div class="btn-wrapper"><button id="mark-hint" type="button">סמן רמז</button><br>
<button id="close-hint" type="button">סגור רמז</button></div>
						</div>
					</div>
				
													<input type="button" name="next" value="הבא" class="wpProQuiz_button wpProQuiz_QuestionButton" style="float: left ; margin-right: 10px ; display: none;"> 													<input type="button" name="tip" value="רמז" class="wpProQuiz_button wpProQuiz_QuestionButton wpProQuiz_TipButton" style="float: left ; display: inline-block; margin-right: 10px ;"> 								<input type="button" name="check" value="סמן" class="wpProQuiz_button wpProQuiz_QuestionButton" style="float: right; margin-right: 10px;"> 								<input type="button" name="back" value="חזרה" class="wpProQuiz_button wpProQuiz_QuestionButton" style="float: right; display: none;"> 								<div style="clear: both;"></div>

							</li>

					<li class="wpProQuiz_listItem" style="" data-type="single" data-question-meta="{&quot;type&quot;:&quot;single&quot;,&quot;question_pro_id&quot;:34,&quot;question_post_id&quot;:0}">
				<div class="wpProQuiz_question_page" style="display:none;">
				שאלה <span>5</span> מתוך <span>9</span>				</div>
				<h5 style="display: none;" class="wpProQuiz_header">
					<span>5</span>. שאלה
				</h5>

				
								<div class="wpProQuiz_question" style="margin: 10px 0px 0px 0px;">
					<div class="wpProQuiz_question_text">
						<p>האם תלמיד נהיגה הוא חלק מהמרחב התעבורתי?</p>
					</div>
					<p class="wpProQuiz_clear" style="clear:both;"></p>

										
										<ul class="wpProQuiz_questionList" data-question_id="34" data-type="single">
						
								<li class="wpProQuiz_questionListItem" data-pos="0">
																			<span style="display:none;">1. </span>
										<label>
											<input class="wpProQuiz_questionInput" autocomplete="off" type="radio" name="question_7_34" value="1" disabled="disabled"> לא. רק אחרי שיקבל רישיון נהיגה יהפוך תלמיד נהיגה לחלק מהמרחב התעבורתי.										</label>

																		</li>
								
								<li class="wpProQuiz_questionListItem" data-pos="1">
																			<span style="display:none;">2. </span>
										<label>
											<input class="wpProQuiz_questionInput" autocomplete="off" type="radio" name="question_7_34" value="2" disabled="disabled"> לא. המרחב התעבורתי לא כולל תלמידי נהיגה הנוהגים ברכב ללימוד נהיגה.										</label>

																		</li>
								
								<li class="wpProQuiz_questionListItem" data-pos="2">
																			<span style="display:none;">3. </span>
										<label>
											<input class="wpProQuiz_questionInput" autocomplete="off" type="radio" name="question_7_34" value="3" disabled="disabled"> כן, אבל רק אם הוא נוהג בדרך בינעירונית.										</label>

																		</li>
								
								<li class="wpProQuiz_questionListItem" data-pos="3">
																			<span style="display:none;">4. </span>
										<label>
											<input class="wpProQuiz_questionInput" autocomplete="off" type="radio" name="question_7_34" value="4" disabled="disabled"> כן, כל מי שנמצא בדרך ומשתמש בה הוא חלק מהמרחב התעבורתי.										</label>

																		</li>
													</ul>
									</div>
									<div class="wpProQuiz_response" style="display: none;">
						<div style="display: none;" class="wpProQuiz_correct">
															<span>
								נכון								</span>
														<div class="wpProQuiz_AnswerMessage"></div>
						</div>
						<div style="display: none;" class="wpProQuiz_incorrect">
															<span>
								לא נכון							</span>
														<div class="wpProQuiz_AnswerMessage"></div>
						</div>
					</div>
				
									<div class="wpProQuiz_tipp" style="position: relative; display: none;">
						<div>
							<h5 style="margin: 0px 0px 10px;" class="wpProQuiz_header">
							רמז							</h5>
							<p><span class="highlight-hint">המרחב התעבורתי הוא מושג רחב הכולל בתוכו את כל מה שנמצא בדרך, את כל מי שמשתמש בדרך ואת כל מה שיש לו השפעה על הנסיעה בדרך.</span><br>
למרחב התעבורתי חברו ארבעה שותפים מרכזיים:</p>
<p>א. פני הדרך – כל מה שישנו בדרך ובסביבתה: מרחבים פתוחים, מרחבים בנויים, כבישים, מדרכות, תמרורים ורמזורים, ועוד. ב.עוברי הדרך – כל משתמשי הדרך הנמצאים בה לכל מטרה: להליכה, לרכיבה, לנסיעה ועוד. ג. כלי רכב – כל כלי הרכב הנעים בדרך על מאפייניהם וסוגיהם השונים. ד. הסביבה – כל תנאי שמשפיע על הנסיעה כגון: תנאי הנראות, שעות היום או הלילה או כמות הנוסעים בכביש.</p>
<p>כפי שתראו בתמונה, להקות בעלי חיים יכולות לנוע בצפיפות כגוף אחד מבלי להתנגש אחד בשני ובלי נפגעים.</p>
<p>שלושה מאפיינים עיקריים למרחב התעבורתי:</p>
<p>א. תנועה רבה ומהירה</p>
<p>ב. שונות ורבגוניות של משתמשי הדרך או של הרכבים הנעים בדרך, כגון השוני העצום שקיים בין רכב לבין אופנוע, או בין נהג ותיק ובעל ניסיון לנהג צעיר חדש חסר ניסיון.</p>
<p>ג. ריבוי מפגשים בין משתמשי הדרך – כל גורם הנע במרחב התעבורתי נתקל בדרכו במשתמשי דרך אחרים הנעים לצידו ומה שיקרה במפגש ביניהם תלוי באמצעי הזהירות שנקטו בהם.</p>
<p>נסכם ונאמר כי סכנות ואי וודאות רבה מאפיינות את המרחב התעבורתי בשל מאפייניו</p>
<p>מורכבותה של מטלת הנהיגה</p>
<p>הנהיגה היא מטלה מורכבת ומסובכת. תראו כמה פעולות על הנהג לבצע בזמן קצר: עליו לאסוף מידע על הסביבה. היות והדרך מתאפיינת בתנועה רבה ומהירה, בשונות גדולה בין משתתפי הדרך ובריבוי מפגשים ביניהם – פעולת איסוף המידע קשה במיוחד שהרי הסביבה משתנה או יכולה להשתנות בכל רגע.</p>
<p>משימה:</p>
<p>לפניכם סרטון הממחיש ומדגים את מורכבות מטלת הנהיגה ביום רגיל במנהטן. בתמונות דומות תתקלו גם בארצנו בערים הגדולות.</p>
<p>התוכלו להצביע על הרגעים בסרטון בהם הנהיגה מורכבת ומחייבת זהירות ועירנות רבה מצד הנהג? רשמו במהלך הצפייה לפחות 5 מצבים שדרשו מהנהג היערכות מיוחדת ותשומת לב מירבית.</p>
<p>הפנייה לסרטון מתוך “תורת החינוך התעבורתי” פרק 1 עמ` 11-12.</p>
<p>למורה: מומלץ מומלץ לעצור את הסרטון מפעם לפעם, לשתף את התלמידים ולהדגיש בפניהם את המורכבות של מצבי הנהיגה שראו בסרטון זה עתה.</p>
<p>מהירות התנועה היא נתון משפיע ביותר. פעמים רבות אירועים מתרחשים בקצב מהיר הרבה יותר ממה שנדרש לאדם באופן טבעי כדי להגיב להם. בנוסף, לכל נהג רצון משלו שמנוגד לעיתים לרצון חברו ופעמים רבות לנהגים אין רגישות מספקת לזולת ונהג צריך לקחת זאת בחשבון.</p>
<p>לכן נכון יהיה לחזור ולהזכיר שהמרחב התעבורתי מתאפיין באי ודאות ובסכנות רבות.</p>
<div class="btn-wrapper"><button id="mark-hint" type="button">סמן רמז</button><br>
<button id="close-hint" type="button">סגור רמז</button></div>
						</div>
					</div>
				
													<input type="button" name="next" value="הבא" class="wpProQuiz_button wpProQuiz_QuestionButton" style="float: left ; margin-right: 10px ; display: none;"> 													<input type="button" name="tip" value="רמז" class="wpProQuiz_button wpProQuiz_QuestionButton wpProQuiz_TipButton" style="float: left ; display: inline-block; margin-right: 10px ;"> 								<input type="button" name="check" value="סמן" class="wpProQuiz_button wpProQuiz_QuestionButton" style="float: right; margin-right: 10px;"> 								<input type="button" name="back" value="חזרה" class="wpProQuiz_button wpProQuiz_QuestionButton" style="float: right; display: none;"> 								<div style="clear: both;"></div>

							</li>

					<li class="wpProQuiz_listItem" style="display: none;" data-type="single" data-question-meta="{&quot;type&quot;:&quot;single&quot;,&quot;question_pro_id&quot;:35,&quot;question_post_id&quot;:0}">
				<div class="wpProQuiz_question_page" style="display:none;">
				שאלה <span>6</span> מתוך <span>9</span>				</div>
				<h5 style="display: none;" class="wpProQuiz_header">
					<span>6</span>. שאלה
				</h5>

				
								<div class="wpProQuiz_question" style="margin: 10px 0px 0px 0px;">
					<div class="wpProQuiz_question_text">
						<p>האם יש סיכונים במרחב התעבורתי?</p>
					</div>
					<p class="wpProQuiz_clear" style="clear:both;"></p>

										
										<ul class="wpProQuiz_questionList" data-question_id="35" data-type="single">
						
								<li class="wpProQuiz_questionListItem" data-pos="0">
																			<span style="display:none;">1. </span>
										<label>
											<input class="wpProQuiz_questionInput" autocomplete="off" type="radio" name="question_7_35" value="1"> ממש לא.										</label>

																		</li>
								
								<li class="wpProQuiz_questionListItem" data-pos="1">
																			<span style="display:none;">2. </span>
										<label>
											<input class="wpProQuiz_questionInput" autocomplete="off" type="radio" name="question_7_35" value="2"> כן, רק בדרכים בינעירוניות.										</label>

																		</li>
								
								<li class="wpProQuiz_questionListItem" data-pos="2">
																			<span style="display:none;">3. </span>
										<label>
											<input class="wpProQuiz_questionInput" autocomplete="off" type="radio" name="question_7_35" value="3"> כן, המרחב התעבורתי מאופיין באי ודאות ובסכנות רבות.										</label>

																		</li>
								
								<li class="wpProQuiz_questionListItem" data-pos="3">
																			<span style="display:none;">4. </span>
										<label>
											<input class="wpProQuiz_questionInput" autocomplete="off" type="radio" name="question_7_35" value="4"> כן, רק בדרכים עירוניות צפופות.										</label>

																		</li>
													</ul>
									</div>
									<div class="wpProQuiz_response" style="display: none;">
						<div style="display: none;" class="wpProQuiz_correct">
															<span>
								נכון								</span>
														<div class="wpProQuiz_AnswerMessage"></div>
						</div>
						<div style="display: none;" class="wpProQuiz_incorrect">
															<span>
								לא נכון							</span>
														<div class="wpProQuiz_AnswerMessage"></div>
						</div>
					</div>
				
									<div class="wpProQuiz_tipp" style="display: none; position: relative;">
						<div>
							<h5 style="margin: 0px 0px 10px;" class="wpProQuiz_header">
							רמז							</h5>
							<p>המרחב התעבורתי הוא מושג רחב הכולל בתוכו את כל מה שנמצא בדרך, את כל מי שמשתמש בדרך ואת כל מה שיש לו השפעה על הנסיעה בדרך.<br>
למרחב התעבורתי חברו ארבעה שותפים מרכזיים:</p>
<p>א. פני הדרך – כל מה שישנו בדרך ובסביבתה: מרחבים פתוחים, מרחבים בנויים, כבישים, מדרכות, תמרורים ורמזורים, ועוד. ב.עוברי הדרך – כל משתמשי הדרך הנמצאים בה לכל מטרה: להליכה, לרכיבה, לנסיעה ועוד. ג. כלי רכב – כל כלי הרכב הנעים בדרך על מאפייניהם וסוגיהם השונים. ד. הסביבה – כל תנאי שמשפיע על הנסיעה כגון: תנאי הנראות, שעות היום או הלילה או כמות הנוסעים בכביש.</p>
<p>כפי שתראו בתמונה, להקות בעלי חיים יכולות לנוע בצפיפות כגוף אחד מבלי להתנגש אחד בשני ובלי נפגעים.</p>
<p>שלושה מאפיינים עיקריים למרחב התעבורתי:</p>
<p>א. תנועה רבה ומהירה</p>
<p>ב. שונות ורבגוניות של משתמשי הדרך או של הרכבים הנעים בדרך, כגון השוני העצום שקיים בין רכב לבין אופנוע, או בין נהג ותיק ובעל ניסיון לנהג צעיר חדש חסר ניסיון.</p>
<p>ג. ריבוי מפגשים בין משתמשי הדרך – כל גורם הנע במרחב התעבורתי נתקל בדרכו במשתמשי דרך אחרים הנעים לצידו ומה שיקרה במפגש ביניהם תלוי באמצעי הזהירות שנקטו בהם.</p>
<p><span class="highlight-hint">נסכם ונאמר כי סכנות ואי וודאות רבה מאפיינות את המרחב התעבורתי בשל מאפייניו</span></p>
<p>מורכבותה של מטלת הנהיגה</p>
<p>הנהיגה היא מטלה מורכבת ומסובכת. תראו כמה פעולות על הנהג לבצע בזמן קצר: עליו לאסוף מידע על הסביבה. היות והדרך מתאפיינת בתנועה רבה ומהירה, בשונות גדולה בין משתתפי הדרך ובריבוי מפגשים ביניהם – פעולת איסוף המידע קשה במיוחד שהרי הסביבה משתנה או יכולה להשתנות בכל רגע.</p>
<p>משימה:</p>
<p>לפניכם סרטון הממחיש ומדגים את מורכבות מטלת הנהיגה ביום רגיל במנהטן. בתמונות דומות תתקלו גם בארצנו בערים הגדולות.</p>
<p>התוכלו להצביע על הרגעים בסרטון בהם הנהיגה מורכבת ומחייבת זהירות ועירנות רבה מצד הנהג? רשמו במהלך הצפייה לפחות 5 מצבים שדרשו מהנהג היערכות מיוחדת ותשומת לב מירבית.</p>
<p>הפנייה לסרטון מתוך “תורת החינוך התעבורתי” פרק 1 עמ` 11-12.</p>
<p>למורה: מומלץ מומלץ לעצור את הסרטון מפעם לפעם, לשתף את התלמידים ולהדגיש בפניהם את המורכבות של מצבי הנהיגה שראו בסרטון זה עתה.</p>
<p>מהירות התנועה היא נתון משפיע ביותר. פעמים רבות אירועים מתרחשים בקצב מהיר הרבה יותר ממה שנדרש לאדם באופן טבעי כדי להגיב להם. בנוסף, לכל נהג רצון משלו שמנוגד לעיתים לרצון חברו ופעמים רבות לנהגים אין רגישות מספקת לזולת ונהג צריך לקחת זאת בחשבון.</p>
<p>לכן נכון יהיה לחזור ולהזכיר שהמרחב התעבורתי מתאפיין באי ודאות ובסכנות רבות.</p>
<div class="btn-wrapper"><button id="mark-hint" type="button">סמן רמז</button><br>
<button id="close-hint" type="button">סגור רמז</button></div>
						</div>
					</div>
				
													<input type="button" name="next" value="הבא" class="wpProQuiz_button wpProQuiz_QuestionButton" style="float: left ; margin-right: 10px ; display: none;"> 													<input type="button" name="tip" value="רמז" class="wpProQuiz_button wpProQuiz_QuestionButton wpProQuiz_TipButton" style="float: left ; display: inline-block; margin-right: 10px ;"> 								<input type="button" name="check" value="סמן" class="wpProQuiz_button wpProQuiz_QuestionButton" style="float: right; margin-right: 10px;"> 								<input type="button" name="back" value="חזרה" class="wpProQuiz_button wpProQuiz_QuestionButton" style="float: right; display: none;"> 								<div style="clear: both;"></div>

							</li>

					<li class="wpProQuiz_listItem" style="display: none;" data-type="single" data-question-meta="{&quot;type&quot;:&quot;single&quot;,&quot;question_pro_id&quot;:36,&quot;question_post_id&quot;:0}">
				<div class="wpProQuiz_question_page" style="display:none;">
				שאלה <span>7</span> מתוך <span>9</span>				</div>
				<h5 style="display: none;" class="wpProQuiz_header">
					<span>7</span>. שאלה
				</h5>

				
								<div class="wpProQuiz_question" style="margin: 10px 0px 0px 0px;">
					<div class="wpProQuiz_question_text">
						<p>מפגש בין עובר דרך לסביבה הוא:</p>
					</div>
					<p class="wpProQuiz_clear" style="clear:both;"></p>

										
										<ul class="wpProQuiz_questionList" data-question_id="36" data-type="single">
						
								<li class="wpProQuiz_questionListItem" data-pos="0">
																			<span style="display:none;">1. </span>
										<label>
											<input class="wpProQuiz_questionInput" autocomplete="off" type="radio" name="question_7_36" value="1"> מפגש בצומת מרומזר בין הולך רגל לנהג.										</label>

																		</li>
								
								<li class="wpProQuiz_questionListItem" data-pos="1">
																			<span style="display:none;">2. </span>
										<label>
											<input class="wpProQuiz_questionInput" autocomplete="off" type="radio" name="question_7_36" value="2"> מפגש בין תמרור להולך רגל.										</label>

																		</li>
								
								<li class="wpProQuiz_questionListItem" data-pos="2">
																			<span style="display:none;">3. </span>
										<label>
											<input class="wpProQuiz_questionInput" autocomplete="off" type="radio" name="question_7_36" value="3"> מפגש בין רוכב אופניים חשמליים לנהג.										</label>

																		</li>
								
								<li class="wpProQuiz_questionListItem" data-pos="3">
																			<span style="display:none;">4. </span>
										<label>
											<input class="wpProQuiz_questionInput" autocomplete="off" type="radio" name="question_7_36" value="4"> נהיגה בשעה שקרני השמש מסנוורות את הנהג.										</label>

																		</li>
													</ul>
									</div>
									<div class="wpProQuiz_response" style="display: none;">
						<div style="display: none;" class="wpProQuiz_correct">
															<span>
								נכון								</span>
														<div class="wpProQuiz_AnswerMessage"></div>
						</div>
						<div style="display: none;" class="wpProQuiz_incorrect">
															<span>
								לא נכון							</span>
														<div class="wpProQuiz_AnswerMessage"></div>
						</div>
					</div>
				
									<div class="wpProQuiz_tipp" style="display: none; position: relative;">
						<div>
							<h5 style="margin: 0px 0px 10px;" class="wpProQuiz_header">
							רמז							</h5>
							<p>המרחב התעבורתי הוא מושג רחב הכולל בתוכו את כל מה שנמצא בדרך, את כל מי שמשתמש בדרך ואת כל מה שיש לו השפעה על הנסיעה בדרך.<br>
למרחב התעבורתי חברו ארבעה שותפים מרכזיים:</p>
<p><span class="highlight-hint">א. פני הדרך – כל מה שישנו בדרך ובסביבתה: מרחבים פתוחים, מרחבים בנויים, כבישים, מדרכות, תמרורים ורמזורים, ועוד. ב.עוברי הדרך – כל משתמשי הדרך הנמצאים בה לכל מטרה: להליכה, לרכיבה, לנסיעה ועוד. ג. כלי רכב – כל כלי הרכב הנעים בדרך על מאפייניהם וסוגיהם השונים. ד. הסביבה – כל תנאי שמשפיע על הנסיעה כגון: תנאי הנראות, שעות היום או הלילה או כמות הנוסעים בכביש.</span></p>
<p>כפי שתראו בתמונה, להקות בעלי חיים יכולות לנוע בצפיפות כגוף אחד מבלי להתנגש אחד בשני ובלי נפגעים.</p>
<p>שלושה מאפיינים עיקריים למרחב התעבורתי:</p>
<p>א. תנועה רבה ומהירה</p>
<p>ב. שונות ורבגוניות של משתמשי הדרך או של הרכבים הנעים בדרך, כגון השוני העצום שקיים בין רכב לבין אופנוע, או בין נהג ותיק ובעל ניסיון לנהג צעיר חדש חסר ניסיון.</p>
<p>ג. ריבוי מפגשים בין משתמשי הדרך – כל גורם הנע במרחב התעבורתי נתקל בדרכו במשתמשי דרך אחרים הנעים לצידו ומה שיקרה במפגש ביניהם תלוי באמצעי הזהירות שנקטו בהם.</p>
<p>נסכם ונאמר כי סכנות ואי וודאות רבה מאפיינות את המרחב התעבורתי בשל מאפייניו</p>
<p>מורכבותה של מטלת הנהיגה</p>
<p>הנהיגה היא מטלה מורכבת ומסובכת. תראו כמה פעולות על הנהג לבצע בזמן קצר: עליו לאסוף מידע על הסביבה. היות והדרך מתאפיינת בתנועה רבה ומהירה, בשונות גדולה בין משתתפי הדרך ובריבוי מפגשים ביניהם – פעולת איסוף המידע קשה במיוחד שהרי הסביבה משתנה או יכולה להשתנות בכל רגע.</p>
<p>משימה:</p>
<p>לפניכם סרטון הממחיש ומדגים את מורכבות מטלת הנהיגה ביום רגיל במנהטן. בתמונות דומות תתקלו גם בארצנו בערים הגדולות.</p>
<p>התוכלו להצביע על הרגעים בסרטון בהם הנהיגה מורכבת ומחייבת זהירות ועירנות רבה מצד הנהג? רשמו במהלך הצפייה לפחות 5 מצבים שדרשו מהנהג היערכות מיוחדת ותשומת לב מירבית.</p>
<p>הפנייה לסרטון מתוך “תורת החינוך התעבורתי” פרק 1 עמ` 11-12.</p>
<p>למורה: מומלץ מומלץ לעצור את הסרטון מפעם לפעם, לשתף את התלמידים ולהדגיש בפניהם את המורכבות של מצבי הנהיגה שראו בסרטון זה עתה.</p>
<p>מהירות התנועה היא נתון משפיע ביותר. פעמים רבות אירועים מתרחשים בקצב מהיר הרבה יותר ממה שנדרש לאדם באופן טבעי כדי להגיב להם. בנוסף, לכל נהג רצון משלו שמנוגד לעיתים לרצון חברו ופעמים רבות לנהגים אין רגישות מספקת לזולת ונהג צריך לקחת זאת בחשבון.</p>
<p>לכן נכון יהיה לחזור ולהזכיר שהמרחב התעבורתי מתאפיין באי ודאות ובסכנות רבות.</p>
<div class="btn-wrapper"><button id="mark-hint" type="button">סמן רמז</button><br>
<button id="close-hint" type="button">סגור רמז</button></div>
						</div>
					</div>
				
													<input type="button" name="next" value="הבא" class="wpProQuiz_button wpProQuiz_QuestionButton" style="float: left ; margin-right: 10px ; display: none;"> 													<input type="button" name="tip" value="רמז" class="wpProQuiz_button wpProQuiz_QuestionButton wpProQuiz_TipButton" style="float: left ; display: inline-block; margin-right: 10px ;"> 								<input type="button" name="check" value="סמן" class="wpProQuiz_button wpProQuiz_QuestionButton" style="float: right; margin-right: 10px;"> 								<input type="button" name="back" value="חזרה" class="wpProQuiz_button wpProQuiz_QuestionButton" style="float: right; display: none;"> 								<div style="clear: both;"></div>

							</li>

					<li class="wpProQuiz_listItem" style="display: none;" data-type="single" data-question-meta="{&quot;type&quot;:&quot;single&quot;,&quot;question_pro_id&quot;:37,&quot;question_post_id&quot;:0}">
				<div class="wpProQuiz_question_page" style="display:none;">
				שאלה <span>8</span> מתוך <span>9</span>				</div>
				<h5 style="display: none;" class="wpProQuiz_header">
					<span>8</span>. שאלה
				</h5>

				
								<div class="wpProQuiz_question" style="margin: 10px 0px 0px 0px;">
					<div class="wpProQuiz_question_text">
						<p>מפגש בין הדרך לעובר דרך הוא:</p>
					</div>
					<p class="wpProQuiz_clear" style="clear:both;"></p>

										
										<ul class="wpProQuiz_questionList" data-question_id="37" data-type="single">
						
								<li class="wpProQuiz_questionListItem" data-pos="0">
																			<span style="display:none;">1. </span>
										<label>
											<input class="wpProQuiz_questionInput" autocomplete="off" type="radio" name="question_7_37" value="1"> מפגש בצומת מרומזר בין הולך רגל לנהג.										</label>

																		</li>
								
								<li class="wpProQuiz_questionListItem" data-pos="1">
																			<span style="display:none;">2. </span>
										<label>
											<input class="wpProQuiz_questionInput" autocomplete="off" type="radio" name="question_7_37" value="2"> מפגש בשעות הלילה בין נהג להולך רגל.										</label>

																		</li>
								
								<li class="wpProQuiz_questionListItem" data-pos="2">
																			<span style="display:none;">3. </span>
										<label>
											<input class="wpProQuiz_questionInput" autocomplete="off" type="radio" name="question_7_37" value="3"> מפגש ביום גשום בין רוכב אופניים חשמליים לנהג.										</label>

																		</li>
								
								<li class="wpProQuiz_questionListItem" data-pos="3">
																			<span style="display:none;">4. </span>
										<label>
											<input class="wpProQuiz_questionInput" autocomplete="off" type="radio" name="question_7_37" value="4"> נהיגה בשעה שקרני השמש מסנוורות את הנהג.										</label>

																		</li>
													</ul>
									</div>
									<div class="wpProQuiz_response" style="display: none;">
						<div style="display: none;" class="wpProQuiz_correct">
															<span>
								נכון								</span>
														<div class="wpProQuiz_AnswerMessage"></div>
						</div>
						<div style="display: none;" class="wpProQuiz_incorrect">
															<span>
								לא נכון							</span>
														<div class="wpProQuiz_AnswerMessage"></div>
						</div>
					</div>
				
									<div class="wpProQuiz_tipp" style="display: none; position: relative;">
						<div>
							<h5 style="margin: 0px 0px 10px;" class="wpProQuiz_header">
							רמז							</h5>
							<p>המרחב התעבורתי הוא מושג רחב הכולל בתוכו את כל מה שנמצא בדרך, את כל מי שמשתמש בדרך ואת כל מה שיש לו השפעה על הנסיעה בדרך.<br>
למרחב התעבורתי חברו ארבעה שותפים מרכזיים:</p>
<p><span class="highlight-hint">א. פני הדרך – כל מה שישנו בדרך ובסביבתה: מרחבים פתוחים, מרחבים בנויים, כבישים, מדרכות, תמרורים ורמזורים, ועוד. ב.עוברי הדרך – כל משתמשי הדרך הנמצאים בה לכל מטרה: להליכה, לרכיבה, לנסיעה ועוד. ג. כלי רכב – כל כלי הרכב הנעים בדרך על מאפייניהם וסוגיהם השונים. ד. הסביבה – כל תנאי שמשפיע על הנסיעה כגון: תנאי הנראות, שעות היום או הלילה או כמות הנוסעים בכביש.</span></p>
<p>כפי שתראו בתמונה, להקות בעלי חיים יכולות לנוע בצפיפות כגוף אחד מבלי להתנגש אחד בשני ובלי נפגעים.</p>
<p>שלושה מאפיינים עיקריים למרחב התעבורתי:</p>
<p>א. תנועה רבה ומהירה</p>
<p>ב. שונות ורבגוניות של משתמשי הדרך או של הרכבים הנעים בדרך, כגון השוני העצום שקיים בין רכב לבין אופנוע, או בין נהג ותיק ובעל ניסיון לנהג צעיר חדש חסר ניסיון.</p>
<p>ג. ריבוי מפגשים בין משתמשי הדרך – כל גורם הנע במרחב התעבורתי נתקל בדרכו במשתמשי דרך אחרים הנעים לצידו ומה שיקרה במפגש ביניהם תלוי באמצעי הזהירות שנקטו בהם.</p>
<p>נסכם ונאמר כי סכנות ואי וודאות רבה מאפיינות את המרחב התעבורתי בשל מאפייניו</p>
<p>מורכבותה של מטלת הנהיגה</p>
<p>הנהיגה היא מטלה מורכבת ומסובכת. תראו כמה פעולות על הנהג לבצע בזמן קצר: עליו לאסוף מידע על הסביבה. היות והדרך מתאפיינת בתנועה רבה ומהירה, בשונות גדולה בין משתתפי הדרך ובריבוי מפגשים ביניהם – פעולת איסוף המידע קשה במיוחד שהרי הסביבה משתנה או יכולה להשתנות בכל רגע.</p>
<p>משימה:</p>
<p>לפניכם סרטון הממחיש ומדגים את מורכבות מטלת הנהיגה ביום רגיל במנהטן. בתמונות דומות תתקלו גם בארצנו בערים הגדולות.</p>
<p>התוכלו להצביע על הרגעים בסרטון בהם הנהיגה מורכבת ומחייבת זהירות ועירנות רבה מצד הנהג? רשמו במהלך הצפייה לפחות 5 מצבים שדרשו מהנהג היערכות מיוחדת ותשומת לב מירבית.</p>
<p>הפנייה לסרטון מתוך “תורת החינוך התעבורתי” פרק 1 עמ` 11-12.</p>
<p>למורה: מומלץ מומלץ לעצור את הסרטון מפעם לפעם, לשתף את התלמידים ולהדגיש בפניהם את המורכבות של מצבי הנהיגה שראו בסרטון זה עתה.</p>
<p>מהירות התנועה היא נתון משפיע ביותר. פעמים רבות אירועים מתרחשים בקצב מהיר הרבה יותר ממה שנדרש לאדם באופן טבעי כדי להגיב להם. בנוסף, לכל נהג רצון משלו שמנוגד לעיתים לרצון חברו ופעמים רבות לנהגים אין רגישות מספקת לזולת ונהג צריך לקחת זאת בחשבון.</p>
<p>לכן נכון יהיה לחזור ולהזכיר שהמרחב התעבורתי מתאפיין באי ודאות ובסכנות רבות.</p>
<div class="btn-wrapper"><button id="mark-hint" type="button">סמן רמז</button><br>
<button id="close-hint" type="button">סגור רמז</button></div>
						</div>
					</div>
				
													<input type="button" name="next" value="הבא" class="wpProQuiz_button wpProQuiz_QuestionButton" style="float: left ; margin-right: 10px ; display: none;"> 													<input type="button" name="tip" value="רמז" class="wpProQuiz_button wpProQuiz_QuestionButton wpProQuiz_TipButton" style="float: left ; display: inline-block; margin-right: 10px ;"> 								<input type="button" name="check" value="סמן" class="wpProQuiz_button wpProQuiz_QuestionButton" style="float: right; margin-right: 10px;"> 								<input type="button" name="back" value="חזרה" class="wpProQuiz_button wpProQuiz_QuestionButton" style="float: right; display: none;"> 								<div style="clear: both;"></div>

							</li>

					<li class="wpProQuiz_listItem" style="display: none;" data-type="single" data-question-meta="{&quot;type&quot;:&quot;single&quot;,&quot;question_pro_id&quot;:38,&quot;question_post_id&quot;:0}">
				<div class="wpProQuiz_question_page" style="display:none;">
				שאלה <span>9</span> מתוך <span>9</span>				</div>
				<h5 style="display: none;" class="wpProQuiz_header">
					<span>9</span>. שאלה
				</h5>

				
								<div class="wpProQuiz_question" style="margin: 10px 0px 0px 0px;">
					<div class="wpProQuiz_question_text">
						<p>מהו "מרחב תעבורתי"?</p>
					</div>
					<p class="wpProQuiz_clear" style="clear:both;"></p>

										
										<ul class="wpProQuiz_questionList" data-question_id="38" data-type="single">
						
								<li class="wpProQuiz_questionListItem" data-pos="0">
																			<span style="display:none;">1. </span>
										<label>
											<input class="wpProQuiz_questionInput" autocomplete="off" type="radio" name="question_7_38" value="1"> מרחב תעבורתי הוא המרחב שבו כלי הרכב נעים בדרך.										</label>

																		</li>
								
								<li class="wpProQuiz_questionListItem" data-pos="1">
																			<span style="display:none;">2. </span>
										<label>
											<input class="wpProQuiz_questionInput" autocomplete="off" type="radio" name="question_7_38" value="2"> מרחב תעבורתי כולל את כל בני האדם המשתמשים בדרך.										</label>

																		</li>
								
								<li class="wpProQuiz_questionListItem" data-pos="2">
																			<span style="display:none;">3. </span>
										<label>
											<input class="wpProQuiz_questionInput" autocomplete="off" type="radio" name="question_7_38" value="3"> מרחב תעבורתי הוא מושג רחב הכולל את כל מי שנמצא בדרך ואת כל מי שמשתמש בדרך.										</label>

																		</li>
								
								<li class="wpProQuiz_questionListItem" data-pos="3">
																			<span style="display:none;">4. </span>
										<label>
											<input class="wpProQuiz_questionInput" autocomplete="off" type="radio" name="question_7_38" value="4"> מרחב תעבורתי הוא מושג רחב הכולל את כל מי שנמצא בדרך ואת כל מי שמשתמש בדרך, מלבד עגלות שאין להן מנוע.										</label>

																		</li>
													</ul>
									</div>
									<div class="wpProQuiz_response" style="display: none;">
						<div style="display: none;" class="wpProQuiz_correct">
															<span>
								נכון								</span>
														<div class="wpProQuiz_AnswerMessage"></div>
						</div>
						<div style="display: none;" class="wpProQuiz_incorrect">
															<span>
								לא נכון							</span>
														<div class="wpProQuiz_AnswerMessage"></div>
						</div>
					</div>
				
									<div class="wpProQuiz_tipp" style="display: none; position: relative;">
						<div>
							<h5 style="margin: 0px 0px 10px;" class="wpProQuiz_header">
							רמז							</h5>
							<p><span class="highlight-hint">המרחב התעבורתי הוא מושג רחב הכולל בתוכו את כל מה שנמצא בדרך, את כל מי שמשתמש בדרך ואת כל מה שיש לו השפעה על הנסיעה בדרך.</span><br>
למרחב התעבורתי חברו ארבעה שותפים מרכזיים:</p>
<p>א. פני הדרך – כל מה שישנו בדרך ובסביבתה: מרחבים פתוחים, מרחבים בנויים, כבישים, מדרכות, תמרורים ורמזורים, ועוד. ב.עוברי הדרך – כל משתמשי הדרך הנמצאים בה לכל מטרה: להליכה, לרכיבה, לנסיעה ועוד. ג. כלי רכב – כל כלי הרכב הנעים בדרך על מאפייניהם וסוגיהם השונים. ד. הסביבה – כל תנאי שמשפיע על הנסיעה כגון: תנאי הנראות, שעות היום או הלילה או כמות הנוסעים בכביש.</p>
<p>כפי שתראו בתמונה, להקות בעלי חיים יכולות לנוע בצפיפות כגוף אחד מבלי להתנגש אחד בשני ובלי נפגעים.</p>
<p>שלושה מאפיינים עיקריים למרחב התעבורתי:</p>
<p>א. תנועה רבה ומהירה</p>
<p>ב. שונות ורבגוניות של משתמשי הדרך או של הרכבים הנעים בדרך, כגון השוני העצום שקיים בין רכב לבין אופנוע, או בין נהג ותיק ובעל ניסיון לנהג צעיר חדש חסר ניסיון.</p>
<p>ג. ריבוי מפגשים בין משתמשי הדרך – כל גורם הנע במרחב התעבורתי נתקל בדרכו במשתמשי דרך אחרים הנעים לצידו ומה שיקרה במפגש ביניהם תלוי באמצעי הזהירות שנקטו בהם.</p>
<p>נסכם ונאמר כי סכנות ואי וודאות רבה מאפיינות את המרחב התעבורתי בשל מאפייניו</p>
<p>מורכבותה של מטלת הנהיגה</p>
<p>הנהיגה היא מטלה מורכבת ומסובכת. תראו כמה פעולות על הנהג לבצע בזמן קצר: עליו לאסוף מידע על הסביבה. היות והדרך מתאפיינת בתנועה רבה ומהירה, בשונות גדולה בין משתתפי הדרך ובריבוי מפגשים ביניהם – פעולת איסוף המידע קשה במיוחד שהרי הסביבה משתנה או יכולה להשתנות בכל רגע.</p>
<p>משימה:</p>
<p>לפניכם סרטון הממחיש ומדגים את מורכבות מטלת הנהיגה ביום רגיל במנהטן. בתמונות דומות תתקלו גם בארצנו בערים הגדולות.</p>
<p>התוכלו להצביע על הרגעים בסרטון בהם הנהיגה מורכבת ומחייבת זהירות ועירנות רבה מצד הנהג? רשמו במהלך הצפייה לפחות 5 מצבים שדרשו מהנהג היערכות מיוחדת ותשומת לב מירבית.</p>
<p>הפנייה לסרטון מתוך “תורת החינוך התעבורתי” פרק 1 עמ` 11-12.</p>
<p>למורה: מומלץ מומלץ לעצור את הסרטון מפעם לפעם, לשתף את התלמידים ולהדגיש בפניהם את המורכבות של מצבי הנהיגה שראו בסרטון זה עתה.</p>
<p>מהירות התנועה היא נתון משפיע ביותר. פעמים רבות אירועים מתרחשים בקצב מהיר הרבה יותר ממה שנדרש לאדם באופן טבעי כדי להגיב להם. בנוסף, לכל נהג רצון משלו שמנוגד לעיתים לרצון חברו ופעמים רבות לנהגים אין רגישות מספקת לזולת ונהג צריך לקחת זאת בחשבון.</p>
<p>לכן נכון יהיה לחזור ולהזכיר שהמרחב התעבורתי מתאפיין באי ודאות ובסכנות רבות.</p>
<div class="btn-wrapper"><button id="mark-hint" type="button">סמן רמז</button><br>
<button id="close-hint" type="button">סגור רמז</button></div>
						</div>
					</div>
				
													<input type="button" name="next" value="סיים מבחן" class="wpProQuiz_button wpProQuiz_QuestionButton" style="float: left ; margin-right: 10px ; display: none;"> 													<input type="button" name="tip" value="רמז" class="wpProQuiz_button wpProQuiz_QuestionButton wpProQuiz_TipButton" style="float: left ; display: inline-block; margin-right: 10px ;"> 								<input type="button" name="check" value="סמן" class="wpProQuiz_button wpProQuiz_QuestionButton" style="float: right; margin-right: 10px;"> 								<input type="button" name="back" value="חזרה" class="wpProQuiz_button wpProQuiz_QuestionButton" style="float: right; display: none;"> 								<div style="clear: both;"></div>

							</li>

			</ol>
	</div>
		</div>
		
</div>
						</div>
				</div>


    // Highlight hint section when 'סמן רמז' button clicked

at 
C:\Users\anist\Desktop\CLIENTS\AVIV\LILAC\app\public\wp-content\themes\hello-theme-child-master\js\learndash-debug.js

and at 
    $(document).on('click', '#close-hint', function () {
        $('.wpProQuiz_tipp').hide();
        $('.highlight-hint').removeClass('highlight-effect');
    });

    C:\Users\anist\Desktop\CLIENTS\AVIV\LILAC\app\public\wp-content\themes\hello-theme-child-master\js\scripts.js