

the users need to be segregated

for instance we have 2 courses

https://lilac.local/courses/client-course/ 1292

https://lilac.local/courses/driveing-students/ 898


when our sample user student uses the reg code and registered into 
https://lilac.local/courses/client-course/ 1292

he should be segregated into the course and not into the other course


currently after successful user reg

from 
[code_registration]

he is enrolled into both courses

