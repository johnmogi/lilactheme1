898 is the students course
1292 is the client course

there shouldnt be a selection inside the shortcode 
[course_registration]

 it should conect directly to 1292

also on the same form add a temporary pay free deom option to the last dropdown for testing


- regarding that hardcode, we should be able to place the course number as in  [course_registration 1292] to allow future flexability


ok the learndash hirerchi goes like this imo

group - course - lessons/ quiz etc

currently the user is logined into both courses 
lets check groups
currently 
למידי חינוך תעבורתי י
is 1294
and
מנוי במסלול פרטי
1320

when the user registered into
[code_registration]
into what groups / courses he is regiserted into?