

- what happens to the reg code

if the user uses it but does not complete the reg?

it remains inactive until reg.